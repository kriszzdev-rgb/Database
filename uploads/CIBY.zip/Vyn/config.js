module.exports = {
  // ========== TELEGRAM ==========
  BOT_TOKEN: "8101847029:AAFoCka5DK2r8-YNVh30gih49xMHIMO69zY",
  OWNER_IDS: ["8517805550"],
  
  // ========== MEDIA ==========
  PHOTO_URL: "https://files.catbox.moe/5ill36.jpg",
  AUDIO_URL: "https://files.catbox.moe/u6kaxr.mp3",
  
  // ========== WHATSAPP ==========
  SESSION_NAME: "session",
  PAIRING_CODE: "VYNXOOOO",
  
  // ========== DATABASE ==========
  PREMIUM_FILE: "premium.json",
  USERS_FILE: "users.json",
  
  // ========== PERFORMANCE ==========
  BATCH_SIZE: 55,
  MAX_NUMBERS: 20000,
  CONCURRENT_LIMIT: 5,
  
  // ========== CREATOR ==========
  CREATOR: "@VynOffc"
};