const { Telegraf, Markup } = require("telegraf");
const chalk = require("chalk");
const pino = require("pino");
const fs = require("fs");
const axios = require("axios");
const { 
  makeWASocket, 
  useMultiFileAuthState, 
  fetchLatestBaileysVersion, 
  DisconnectReason 
} = require("@whiskeysockets/baileys");

// ========== CONFIG ==========
const CONFIG = require("./config");

// ========== INIT BOT ==========
const bot = new Telegraf(CONFIG.BOT_TOKEN);

// ========== WHATSAPP CLIENT ==========
let sock = null;
let waConnected = false;
let waUserInfo = null;
let reconnectTimer = null;
let lastConnectionStatus = false;
let startTime = null;

// ========== DATABASE ==========
let premiumUsers = [];
let registeredUsers = [];

function loadDatabase() {
  try {
    if (fs.existsSync(CONFIG.PREMIUM_FILE)) {
      premiumUsers = JSON.parse(fs.readFileSync(CONFIG.PREMIUM_FILE));
    }
    if (fs.existsSync(CONFIG.USERS_FILE)) {
      registeredUsers = JSON.parse(fs.readFileSync(CONFIG.USERS_FILE));
    }
  } catch (e) {
    console.log("❌ Error load DB:", e.message);
  }
}

function savePremium() {
  fs.writeFileSync(CONFIG.PREMIUM_FILE, JSON.stringify(premiumUsers, null, 2));
}

function saveUsers() {
  fs.writeFileSync(CONFIG.USERS_FILE, JSON.stringify(registeredUsers, null, 2));
}

loadDatabase();

// ========== ASCII ART ==========
const ASCII_ART = `
${chalk.cyan('⠀⠀⠀⠀⣴⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢶⡄⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⣼⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠹⠀⠀⠀')}
${chalk.cyan('⠀⠀⡰⡇⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡞⠀⠷⡀⠀')}
${chalk.cyan('⠀⠀⡇⢸⢄⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣦⠤⠤⠤⠤⠴⢚⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢇⢰⠀⡇⠀')}
${chalk.cyan('⠀⣰⢇⢬⡜⣜⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣯⡠⡴⣾⡷⠃⢠⡄⠨⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠞⡞⢎⢀⢷⠀')}
${chalk.cyan('⠀⣿⠘⡜⡜⣌⢌⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⢎⣬⠤⢤⣬⡍⣑⣬⠀⡇⣆⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢋⢎⠞⠞⡞⢨⡄')}
${chalk.cyan('⢸⠙⡄⡘⣜⣌⢮⠣⡙⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠃⠸⣟⣋⠥⢯⠁⢀⡈⣀⣠⠸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠞⡡⣫⢊⢞⠞⡄⡎⡇')}
${chalk.cyan('⢸⢧⢙⡝⣌⢮⠢⣑⢬⣺⣌⡑⠲⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣶⡾⣻⣟⣿⢯⣷⣵⣾⡋⠀⠀⠀⠀⠀⠀⠀⣀⣠⡴⢚⣩⣾⣪⢔⡥⢫⢎⣜⣜⣠⢻')}
${chalk.cyan('⢸⡈⢺⢮⠪⡢⣝⠪⣑⡯⣕⡂⢽⣄⡀⢭⣓⢆⠀⠀⠀⠀⠀⢬⣿⢳⡽⣏⡶⣻⣏⡞⣽⡅⠀⠀⠀⠀⢠⢖⡫⠅⣀⣼⢅⣒⡭⣗⡥⢚⠵⡫⣪⣺⠃⣸')}
${chalk.cyan('⢨⠱⣴⣕⢵⣬⡲⢽⣲⡭⠵⣶⡿⠤⢤⣙⠈⡏⢣⡀⠀⠠⣼⣿⢯⣻⣝⣯⡟⣼⣷⣟⣿⣿⡀⠀⠀⡰⠃⡇⢈⡡⠤⢼⣵⡶⠭⣟⡺⠕⣫⣾⢕⢕⡜⢹')}
${chalk.cyan('⢸⢦⢨⡪⣓⠍⣛⠵⢺⣿⣭⣭⣟⣒⣒⡢⠀⢰⡀⠙⠒⢲⣿⣿⣾⣹⣯⣷⣭⣾⣹⣎⣿⣿⡗⠒⠚⠁⡸⠀⢰⣒⣒⣻⣯⣭⣭⣿⠲⢝⡋⢕⡭⣪⣠⢺')}
${chalk.cyan('⢸⣆⠙⡯⣲⠭⣚⣻⢯⣧⣤⣴⣿⡖⠒⣚⡃⠀⢻⢉⡉⠉⠉⠉⠉⢉⠉⠉⡏⠉⠉⠉⢉⡉⠉⠉⠉⢹⠃⠀⣛⡒⠒⣾⣷⣤⣤⣯⢟⣛⡪⣕⡪⡛⢁⡞')}
${chalk.cyan('⠈⣧⡙⡻⣖⡭⣗⣚⣉⣗⣒⣲⢽⣯⠭⢑⣺⡄⢸⢸⡇⠀⠀⠀⠀⢸⡄⠀⡇⢀⡴⠿⠩⣍⣛⢢⡀⢸⢀⣼⣒⠩⢭⣿⢷⣒⣚⣏⣙⣒⡯⣕⡾⡛⣡⠇')}
${chalk.cyan('⠀⠳⡉⠺⢷⣊⠭⠭⣉⠭⣯⣉⡷⣿⣯⣕⣿⣿⣿⢪⣧⣴⣶⣶⣤⣾⠇⠀⡇⣼⣭⣯⣾⣽⣿⣿⡇⢸⡿⡯⣕⣽⣿⡷⣏⣹⠯⢭⡭⠭⢅⣲⠍⠋⡱⠁')}
${chalk.cyan('⠀⠀⢯⡓⢭⣛⣒⣭⣭⣥⡼⢯⣽⢯⣿⣿⣿⣼⣸⠀⠛⢷⢿⣿⣯⣿⣤⣤⣧⣼⣿⣿⣿⣿⠛⠛⠃⢸⣸⣼⣿⣿⣯⢿⣽⠿⣤⣭⣭⣕⣒⣭⠗⣩⠃⠀')}
${chalk.cyan('⠀⠀⠘⢏⡙⠛⣧⡴⠶⣤⣿⠻⣽⣿⣟⣿⡿⣿⣿⠀⠀⠸⣿⡿⢸⣿⣿⣿⢻⣿⣿⣿⠛⠛⠓⠂⠀⢸⣯⣻⣿⣿⣿⣿⡽⢻⣦⡴⠦⣤⡟⢓⣉⠟⠀⠀')}
${chalk.cyan('⠀⠀⠀⠈⢮⣅⣒⣺⣿⡶⣶⣟⣣⣝⣾⣻⡿⣿⣺⢻⡟⡛⠛⠛⢻⣿⣉⠁⠈⢉⣿⣿⠛⠛⠛⠛⠛⢻⣻⣿⣿⣿⣞⣿⣛⣳⡶⣾⣿⣒⣈⣭⠋⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠓⣄⠤⠽⠶⢿⣋⣳⢿⣻⣕⡮⣺⣽⢼⣿⣷⢿⣷⢸⣿⣿⣤⣤⣸⣿⣿⣀⣴⣶⣦⡀⢸⣽⡺⣞⣽⣻⢿⣏⣽⠷⠾⠤⢄⡖⠁⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠈⠙⢭⣍⣉⣉⠷⢾⣽⢾⡿⢿⣾⣿⣿⣿⣿⣟⣦⢻⣿⣿⣿⣿⣿⣷⡿⠃⢀⣿⡇⡾⣯⢿⣿⢮⣽⠾⢏⣉⣉⣭⠟⠉⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠲⠶⠍⠉⠭⠽⢛⣏⣿⣽⣿⣿⣯⣯⣿⢍⡻⡿⢻⣿⠋⠀⢀⣾⡟⣼⣩⠙⠿⠼⠏⠉⠵⠶⠒⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⢽⡽⣾⣿⣿⣽⣿⠿⢧⡇⣿⡇⠀⣠⣾⣏⣾⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢼⡭⣾⢳⡧⡽⣿⣿⡿⠿⢤⡀⡇⠙⠿⠿⣻⣷⣿⢼⡶⣷⢽⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠹⠙⢦⡀⠀⠀⠀⠀⠀⠀⠀⢸⢶⣿⢹⣯⠻⢿⡹⣿⣷⢢⢤⣧⡤⣶⣿⢽⠹⠾⣽⡟⣿⡶⡇⠀⠀⠀⠀⠀⠀⠀⢀⠔⢩⠃⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠘⠯⣁⠀⠀⠑⣄⠀⣀⠀⠀⠀⣠⠃⢀⠟⠁⠀⠀⡼⣿⣿⣩⡿⡉⣩⡿⡣⢿⡾⡆⠀⠀⠈⠣⡀⠸⡄⠀⠀⠀⡀⠀⡴⠁⠀⠈⣨⠝⠃⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠈⢦⡀⢀⡼⠋⠉⠑⣄⠴⠣⡴⠁⠀⠀⠀⢰⢣⢻⡎⢿⣥⠋⢙⡥⠻⡳⠻⠸⡄⠀⠀⠀⠘⣦⠞⠦⡴⠋⠉⠙⣄⠀⢀⠞⠁⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠳⣘⡿⢦⡴⡺⣻⠁⡤⣮⠇⠀⠀⢀⡎⡌⡎⣟⢻⢃⠗⢺⣃⡷⣧⢇⢇⢣⠀⠀⠀⡼⣵⢤⠨⣾⣗⢤⠾⣿⣠⠋⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣟⣡⢪⣾⣿⣽⣒⠤⣼⢸⢹⢰⡸⡎⡏⢦⢼⢿⡇⡞⡘⡜⣜⣦⠤⣚⣽⡻⣦⢕⣌⣯⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠙⠫⢿⡿⣿⣷⣦⣯⣽⣻⣷⠧⢷⣤⡼⣼⣼⣿⣓⣏⣥⣲⣀⠘⣿⡯⠛⠉⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢑⡿⡯⣞⣿⣿⣾⡆⠈⣏⢯⣿⣿⣷⣟⣿⡿⣿⢿⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡼⣜⣱⣣⢣⢫⢋⡽⡹⢹⠉⡏⣏⠹⣱⡱⣼⣌⡪⢇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.cyan('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠑⠛⠛⠛⠓⣿⣳⠵⠋⠓⢼⣟⡟⠓⠛⠓⠓⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀')}
${chalk.reset('')}`;

// ========== MIDDLEWARE ==========
function isOwner(userId) {
  return CONFIG.OWNER_IDS.includes(userId.toString());
}

function isPremium(userId) {
  return isOwner(userId) || premiumUsers.includes(userId.toString());
}

const checkOwner = (ctx, next) => {
  if (!isOwner(ctx.from.id)) {
    ctx.replyWithHTML("<blockquote><b>❌ Lu bukan owner bego!</b></blockquote>");
    return;
  }
  return next();
};

const checkPremium = (ctx, next) => {
  if (!isPremium(ctx.from.id)) {
    ctx.replyWithHTML(
      "<blockquote><b>💎 FITUR PREMIUM</b>\n\nHubungi @VynOffc untuk upgrade.</blockquote>"
    );
    return;
  }
  return next();
};

// ========== HELPER FUNCTIONS ==========
function formatNumber(phone) {
  if (!phone) return '';
  let clean = phone.replace(/\D/g, '');
  if (clean.startsWith('0')) clean = '62' + clean.slice(1);
  if (clean.startsWith('8')) clean = '62' + clean;
  return clean;
}

function calculateBioAge(setAt) {
  if (!setAt) return null;
  const now = new Date();
  const bioDate = new Date(setAt);
  const diff = now - bioDate;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (86400000)) / 3600000);
  if (days > 0) return `${days} hari ${hours} jam lalu`;
  if (hours > 0) return `${hours} jam lalu`;
  return "Baru saja";
}

function formatTime(ms) {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)} detik`;
  return `${(ms / 60000).toFixed(1)} menit`;
}

function extractLinks(text) {
  if (!text) return [];
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.match(urlRegex) || [];
}

function createProgressBar(current, total, length = 10) {
  const percentage = current / total;
  const filled = Math.round(length * percentage);
  const empty = length - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
}

function maskPhone(phone) {
  if (!phone) return 'Unknown';
  return phone.length > 8 
    ? phone.substring(0, 4) + '****' + phone.substring(phone.length - 2)
    : phone;
}

function getUptime() {
  if (!startTime) return "Belum terhubung";
  const diff = Date.now() - startTime;
  const hours = Math.floor(diff / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return `${hours} jam ${minutes} menit ${seconds} detik`;
}

// ========== WHATSAPP CONNECTION ==========
async function startWhatsApp() {
  console.log(chalk.yellow("🔄 Starting WhatsApp..."));

  const { state, saveCreds } = await useMultiFileAuthState(CONFIG.SESSION_NAME);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 30000,
    defaultQueryTimeoutMs: 60000
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) console.log(chalk.green("\n📱 QR Ready"));

    if (connection === "open") {
      waConnected = true;
      waUserInfo = sock.user;
      startTime = Date.now();
      console.log(chalk.green("✅ WhatsApp Connected!"));

      const userPhone = waUserInfo?.id?.split(':')[0] || 'Unknown';
      const userName = waUserInfo?.name || 'Unknown';

      CONFIG.OWNER_IDS.forEach(ownerId => {
        bot.telegram.sendMessage(
          ownerId,
          `<blockquote><b>✅ Whatsapp Connection</b>\n\n📱 Nomor : <code>${userPhone}</code>\n👤 Nama : ${userName}</blockquote>`,
          { parse_mode: "HTML" }
        ).catch(() => {});
      });

      lastConnectionStatus = true;

      premiumUsers.forEach(userId => {
        bot.telegram.sendMessage(
          userId,
          `<blockquote><b>✅ WhatsApp Terhubung!</b>\nBot siap digunakan.</blockquote>`,
          { parse_mode: "HTML" }
        ).catch(() => {});
      });
    }

    if (connection === "close") {
      waConnected = false;
      waUserInfo = null;
      startTime = null;

      if (reconnectTimer) clearTimeout(reconnectTimer);

      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

      if (shouldReconnect) {
        console.log(chalk.yellow("🔄 Connection lost, reconnecting in 5s..."));

        if (lastConnectionStatus) {
          CONFIG.OWNER_IDS.forEach(ownerId => {
            bot.telegram.sendMessage(
              ownerId,
              `<blockquote><b>⚠️ WhatsApp Connection Lost</b>\n\nMencoba reconnect dalam 5 detik...</blockquote>`,
              { parse_mode: "HTML" }
            ).catch(() => {});
          });
          lastConnectionStatus = false;
        }

        reconnectTimer = setTimeout(startWhatsApp, 5000);
      } else {
        console.log(chalk.red("❌ WhatsApp logged out"));
        CONFIG.OWNER_IDS.forEach(ownerId => {
          bot.telegram.sendMessage(
            ownerId,
            `<blockquote><b>❌ WhatsApp Logged Out</b>\n\nSilakan /pair ulang.</blockquote>`,
            { parse_mode: "HTML" }
          ).catch(() => {});
        });
      }
    }
  });
}

// ========== FUNGSI CEK BIO DENGAN PROGRESS ==========
async function checkBioWithProgress(numbers, ctx, msgId, chatId) {
  const results = [];
  const total = numbers.length;
  let processed = 0;

  const stats = {
    terdaftar: 0,
    tidak: 0,
    withBio: 0,
    withoutBio: 0,
    business: 0
  };

  for (let i = 0; i < total; i += CONFIG.BATCH_SIZE) {
    const batch = numbers.slice(i, i + CONFIG.BATCH_SIZE);

    const batchPromises = batch.map(async (original) => {
      const clean = formatNumber(original);
      const jid = clean + "@s.whatsapp.net";

      try {
        const [exists] = await sock.onWhatsApp(jid);
        if (!exists || !exists.exists) {
          processed++;
          stats.tidak++;
          return { original, clean, registered: false };
        }

        const [status, biz] = await Promise.allSettled([
          sock.fetchStatus(jid).catch(() => null),
          sock.getBusinessProfile(jid).catch(() => null)
        ]);

        const bio = status.status === 'fulfilled' ? status.value?.status : null;
        const setAt = status.status === 'fulfilled' ? status.value?.setAt : null;
        const isBiz = biz.status === 'fulfilled' && biz.value?.wid;
        const links = extractLinks(bio);

        stats.terdaftar++;
        if (bio && bio.length > 0) stats.withBio++;
        else stats.withoutBio++;
        if (isBiz) stats.business++;

        processed++;

        return {
          original, clean,
          registered: true,
          bio, setAt,
          isBusiness: isBiz,
          links
        };

      } catch (err) {
        processed++;
        stats.tidak++;
        return { original, clean, registered: false };
      }
    });

    const batchResults = await Promise.all(batchPromises);
    results.push(...batchResults);

    const progress = createProgressBar(processed, total);
    await ctx.telegram.editMessageText(
      chatId,
      msgId,
      null,
      `<blockquote><b>⌛ Otw Cek ${processed}/${total}</b>\n${progress}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  return { results, stats };
}

// ========== GENERATE FILE HASIL ==========
function generateResultFile(results, numbers, source, timeTaken, stats) {
  const filename = `hasil_cekbio_${Date.now()}.txt`;

  let content = "";

  content += `📊 HASIL CEK ${numbers.length} NOMOR\n\n`;
  content += `✅ Terdaftar: ${stats.terdaftar}\n`;
  content += `❌ Tidak: ${stats.tidak}\n`;
  content += `📝 Dengan bio: ${stats.withBio}\n`;
  content += `🏢 Business: ${stats.business}\n`;
  content += `⏱️ Waktu: ${formatTime(timeTaken)}\n\n`;
  content += `📁 Sumber Data: ${source}\n`;
  content += `🕒 ${new Date().toLocaleString('id-ID')}\n`;
  content += `----------------------------------------\n\n`;

  const withBioResults = results.filter(r => r.registered && r.bio?.length > 0);
  if (withBioResults.length > 0) {
    content += `✅ NOMOR YANG ADA BIO NYA (${withBioResults.length})\n\n`;

    const byYear = {};
    withBioResults.forEach(r => {
      let year = 'Tidak diketahui';
      if (r.setAt) {
        year = new Date(r.setAt).getFullYear().toString();
      }
      if (!byYear[year]) byYear[year] = [];
      byYear[year].push(r);
    });

    const years = Object.keys(byYear).sort((a, b) => {
      if (a === 'Tidak diketahui') return 1;
      if (b === 'Tidak diketahui') return -1;
      return b - a;
    });

    years.forEach(year => {
      content += `Tahun ${year}\n\n`;
      byYear[year].forEach(r => {
        content += `└─ 📱 ${r.original}\n`;

        if (r.bio && r.bio.trim() !== '') {
          content += `   └─ 📝 "${r.bio}"\n`;
        } else {
          content += `   └─ 📝 (Tidak ada bio / private)\n`;
        }

        if (r.setAt) {
          const d = new Date(r.setAt);
          const dateStr = d.toLocaleDateString('id-ID');
          const timeStr = d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
          content += `      └─ ⏰ ${dateStr}, ${timeStr}\n`;
        }

        content += `      └─ 🏢 Business: ${r.isBusiness ? '✅ Ya' : '❌ Tidak'}\n`;

        if (r.links && r.links.length > 0) {
          content += `      └─ 🌐 Link:\n`;
          r.links.slice(0, 3).forEach(link => content += `         └─ ${link}\n`);
        }
        content += `\n`;
      });
    });
    content += `----------------------------------------\n\n`;
  }

  const withoutBioResults = results.filter(r => r.registered && (!r.bio || r.bio.length === 0));
  if (withoutBioResults.length > 0) {
    content += `📵 NOMOR TANPA BIO / PRIVASI (${withoutBioResults.length})\n\n`;
    withoutBioResults.forEach(r => {
      content += `└─ 📱 ${r.original}\n`;
      content += `   └─ 🏢 Business: ${r.isBusiness ? '✅ Ya' : '❌ Tidak'}\n`;
      if (r.links && r.links.length > 0) {
        content += `      └─ 🌐 Link: ${r.links[0]}\n`;
      }
      content += `\n`;
    });
    content += `----------------------------------------\n\n`;
  }

  const notRegisteredResults = results.filter(r => !r.registered);
  if (notRegisteredResults.length > 0) {
    content += `🚫 NOMOR TIDAK TERDAFTAR (${notRegisteredResults.length})\n\n`;
    notRegisteredResults.forEach(r => {
      content += `└─ 📱 ${r.original}\n`;
    });
    content += `\n----------------------------------------\n`;
  }

  content += `\n🔥 DIBUAT OLEH ${CONFIG.CREATOR} 🔥\n`;
  content += `💀 PREMAN DIGITAL INDONESIA 💀\n`;

  fs.writeFileSync(filename, content);
  return filename;
}

// ========== BUTTON MENU ==========
const backButton = Markup.inlineKeyboard([
  [Markup.button.callback("↩️ ʙᴀᴄᴋ", "back_menu")]
]);

const mainKeyboard = Markup.inlineKeyboard([
  [Markup.button.callback("📱 sᴛᴀᴛᴜs ᴡᴀ", "status_wa")],
  [Markup.button.callback("📋 ᴄᴇᴋ ʙɪᴏ", "cekbio_menu"), Markup.button.callback("💎 ᴘʀᴇᴍɪᴜᴍ", "premium_menu")],
  [Markup.button.url("👑 ᴏᴡɴᴇʀ", `https://t.me/${CONFIG.CREATOR.replace('@', '')}`)]
]);

// ========== BUTTON HANDLERS ==========
bot.action("status_wa", async (ctx) => {
  await ctx.answerCbQuery();

  const status = waConnected ? "✅ Connection" : "❌ No Connection";
  
  let msg = `
<blockquote>
<b>📱 Status Sender</b>

📡 Status : ${status}
</blockquote>
  `;

  if (waConnected && waUserInfo) {
    const userPhone = waUserInfo.id?.split(':')[0] || 'Unknown';
    const maskedPhone = maskPhone(userPhone);
    const userName = waUserInfo.name || 'Unknown';
    
    msg = `
<blockquote>
<b>📱 Status Sender</b>

📡 Status : ${status}
📱 Nomor  : <code>${maskedPhone}</code>
👤 Nama   : ${userName}
</blockquote>
    `;
  }

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback("🔌 ᴘᴜᴛᴜsᴋᴀɴ sᴇɴᴅᴇʀ", "disconnect_wa")],
    [Markup.button.callback("⏱️ ʟɪʜᴀᴛ ᴡᴀᴋᴛᴜ ᴏɴ", "wa_uptime")],
    [Markup.button.callback("↩️ ʙᴀᴄᴋ", "back_menu")]
  ]);

  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: msg,
        parse_mode: "HTML"
      },
      keyboard
    );
  } catch (err) {
    console.log("Edit media error:", err.message);
    await ctx.replyWithPhoto(CONFIG.PHOTO_URL, {
      caption: msg,
      parse_mode: "HTML",
      ...keyboard
    });
  }
});

// Putuskan Sender
bot.action("disconnect_wa", checkOwner, async (ctx) => {
  await ctx.answerCbQuery();

  if (!waConnected) {
    return ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: "<blockquote>❌ WhatsApp sudah dalam keadaan terputus!</blockquote>",
        parse_mode: "HTML"
      },
      backButton
    );
  }

  try {
    await sock.logout();
    waConnected = false;
    waUserInfo = null;
    startTime = null;
    
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: "<blockquote>✅ WhatsApp berhasil diputuskan!</blockquote>",
        parse_mode: "HTML"
      },
      backButton
    );
  } catch (err) {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: `<blockquote>❌ Gagal memutuskan: ${err.message}</blockquote>`,
        parse_mode: "HTML"
      },
      backButton
    );
  }
});

// Waktu Terhubung
bot.action("wa_uptime", async (ctx) => {
  await ctx.answerCbQuery();

  if (!waConnected || !waUserInfo) {
    return ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: "<blockquote>❌ WhatsApp tidak terhubung!</blockquote>",
        parse_mode: "HTML"
      },
      backButton
    );
  }

  const uptimeText = `<blockquote>⏱️ Sender On ${getUptime()}</blockquote>`;

  await ctx.editMessageMedia(
    {
      type: "photo",
      media: CONFIG.PHOTO_URL,
      caption: uptimeText,
      parse_mode: "HTML"
    },
    backButton
  );
});

// Menu Cek Bio
bot.action("cekbio_menu", async (ctx) => {
  await ctx.answerCbQuery();

  const msg = `
<blockquote>
<b>📋 𝐂𝐄𝐊 𝐁𝐈𝐎</b>

╭─────────────────✦
├ /pair  ─  Pairing Sender
├ /status  ─  Status Sender
├ /cekbio  ─  Cek Bio
├ /cekfile  ─  Cek Bio Via File
├ /ivas  ─  Cek Ivas
├ /addprem  ─  Add User Prem
├ /delprem  ─  Hapus User Prem
├ /listprem  ─  Lihat User Prem
╰─────────────────✦
</blockquote>
  `;

  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: msg,
        parse_mode: "HTML"
      },
      backButton
    );
  } catch (err) {
    console.log("Edit media error:", err.message);
    await ctx.replyWithPhoto(CONFIG.PHOTO_URL, {
      caption: msg,
      parse_mode: "HTML",
      ...backButton
    });
  }
});

// Menu Premium
bot.action("premium_menu", async (ctx) => {
  await ctx.answerCbQuery();

  const msg = `
<blockquote>
<b>💎 𝐏𝐑𝐄𝐌𝐈𝐔𝐌</b>

Silahkan Buy Di Owner Mbudd
</blockquote>
  `;

  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: msg,
        parse_mode: "HTML"
      },
      backButton
    );
  } catch (err) {
    console.log("Edit media error:", err.message);
    await ctx.replyWithPhoto(CONFIG.PHOTO_URL, {
      caption: msg,
      parse_mode: "HTML",
      ...backButton
    });
  }
});

// Menu Utama
bot.action("back_menu", async (ctx) => {
  await ctx.answerCbQuery();

  const userId = ctx.from.id.toString();
  const statusWA = waConnected ? "✅ Terhubung" : "❌ Terputus";
  const userStatus = isOwner(userId) ? "👑 Owner" : isPremium(userId) ? "💎 Premium" : "👤 Free";

  const caption = `
<blockquote>⚔️ 𝖈𝖊𝖐 𝖇𝖎𝖔 𝖜𝖍𝖆𝖙𝖘𝖆𝖕𝖕</blockquote>

<blockquote>🧬 𝖔𝖜𝖓𝖊𝖗 𝖕𝖗𝖊𝖒𝖎𝖚𝖒</blockquote>
/pair
/status
/addprem
/delprem
/listprem

<blockquote>📋 𝖈𝖍𝖊𝖈𝖐𝖊𝖗 𝖇𝖎𝖔 𝖜𝖆</blockquote>
/cekbio
/cekfile

<blockquote>📊 STATUS
• WA: ${statusWA}
• Akun: ${userStatus}</blockquote>
  `;

  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: CONFIG.PHOTO_URL,
        caption: caption,
        parse_mode: "HTML"
      },
      mainKeyboard
    );
  } catch (err) {
    console.log("Edit media error:", err.message);
    await ctx.replyWithPhoto(CONFIG.PHOTO_URL, {
      caption: caption,
      parse_mode: "HTML",
      ...mainKeyboard
    });
  }
});

// ========== START COMMAND ==========
bot.start(async (ctx) => {
  const userId = ctx.from.id.toString();

  if (!registeredUsers.includes(userId) && !isOwner(userId)) {
    registeredUsers.push(userId);
    saveUsers();
    bot.telegram.sendMessage(
      CONFIG.OWNER_IDS[0],
      `<blockquote><b>👤 User Baru</b>\nID: <code>${userId}</code>\nUsername: @${ctx.from.username || '-'}</blockquote>`,
      { parse_mode: "HTML" }
    ).catch(() => {});
  }

  const statusWA = waConnected ? "✅ Terhubung" : "❌ Terputus";
  const userStatus = isOwner(userId) ? "👑 Owner" : isPremium(userId) ? "💎 Premium" : "👤 Free";

  const caption = `
<blockquote>⚔️ 𝖈𝖊𝖐 𝖇𝖎𝖔 𝖜𝖍𝖆𝖙𝖘𝖆𝖕𝖕</blockquote>

<blockquote>🧬 𝖔𝖜𝖓𝖊𝖗 𝖕𝖗𝖊𝖒𝖎𝖚𝖒</blockquote>
/pair
/status
/addprem
/delprem
/listprem

<blockquote>📋 𝖈𝖍𝖊𝖈𝖐𝖊𝖗 𝖇𝖎𝖔 𝖜𝖆</blockquote>
/cekbio
/cekfile

<blockquote>📊 STATUS
• WA: ${statusWA}
• Akun: ${userStatus}</blockquote>
  `;

  await ctx.replyWithPhoto(CONFIG.PHOTO_URL, {
    caption: caption,
    parse_mode: "HTML", 
    ...mainKeyboard
  });

  await ctx.replyWithAudio(CONFIG.AUDIO_URL).catch(() => {});
});

// ========== PAIRING COMMAND ==========
bot.command("pair", checkOwner, async (ctx) => {
  const args = ctx.message.text.split(" ");
  
  if (args.length < 2) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Format: /pair 6281234567890</b></blockquote>"
    );
  }

  const phone = formatNumber(args[1]);
  const msg = await ctx.replyWithHTML(
    `<blockquote><b>🔄 Meminta Kode Untuk ${phone}...</b></blockquote>`
  );

  if (!sock) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>🔄 Start WA...</b></blockquote>`,
      { parse_mode: "HTML" }
    );
    
    await startWhatsApp();
    await new Promise(resolve => setTimeout(resolve, 5000));
  }

  try {
    const code = await sock.requestPairingCode(phone, CONFIG.PAIRING_CODE);
    const formatted = code?.match(/.{1,4}/g)?.join("-") || code;

    const pairMsg = `
<blockquote>
<b>🔒 PAIRING CODE</b>

<b>📱 Nomor :</b> <code>${phone}</code>
<b>🔢 Kode   :</b> <code>${formatted}</code>

<b>MASUKAN KODENYA KE WHATSAPP/WHATSAPP BUSSINESS</b>
</blockquote>
    `;

    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      pairMsg,
      {
        parse_mode: "HTML",
        reply_markup: backButton.reply_markup
      }
    );
  } catch (err) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>❌ Gagal: ${err.message}</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

// ========== STATUS COMMAND ==========
bot.command("status", (ctx) => {
  const status = waConnected ? "✅ Terhubung" : "❌ Terputus";
  
  let msg = `
<blockquote>
<b>📱 Status WhatsApp</b>

🔌 Koneksi: ${status}
</blockquote>
  `;

  if (waConnected && waUserInfo) {
    const userPhone = waUserInfo.id?.split(':')[0] || 'Unknown';
    
    msg = `
<blockquote>
<b>📱 Status WhatsApp</b>

🔌 Koneksi: ${status}
📱 Nomor  : <code>${userPhone}</code>
👤 Nama   : ${waUserInfo.name || 'Unknown'}
</blockquote>
    `;
  }

  ctx.replyWithHTML(msg, backButton);
});

// ========== CEK BIO COMMAND ==========
bot.command("cekbio", checkPremium, async (ctx) => {
  if (!waConnected) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ WA Belum Terhubung!</b></blockquote>"
    );
  }

  const text = ctx.message.text;
  const numbers = text
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .flatMap(line => line.split(' '))
    .filter(n => n !== '/cekbio' && n.length > 0);

  if (numbers.length < 1) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Format: /cekbio 62811 62822 62833</b></blockquote>"
    );
  }

  if (numbers.length > CONFIG.MAX_NUMBERS) {
    return ctx.replyWithHTML(
      `<blockquote><b>❌ Maksimal ${CONFIG.MAX_NUMBERS} Nomor</b></blockquote>`
    );
  }

  const progressBar = createProgressBar(0, numbers.length);
  const msg = await ctx.replyWithHTML(
    `<blockquote><b>⌛ Otw Cek 0/${numbers.length}</b>\n${progressBar}</blockquote>`
  );
  
  const startTime = Date.now();

  try {
    const { results, stats } = await checkBioWithProgress(
      numbers,
      ctx,
      msg.message_id,
      ctx.chat.id
    );
    
    const timeTaken = Date.now() - startTime;

    let finalResult = `📊 HASIL CEK ${numbers.length} NOMOR\n\n`;
    finalResult += `✅ Terdaftar   : ${stats.terdaftar}\n`;
    finalResult += `❌ Tidak       : ${stats.tidak}\n`;
    finalResult += `📝 Dengan bio  : ${stats.withBio}\n`;
    finalResult += `🏢 Business    : ${stats.business}\n`;
    finalResult += `⏱️ Waktu       : ${formatTime(timeTaken)}`;

    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      finalResult,
      { parse_mode: "Markdown" }
    );

    const filename = generateResultFile(
      results,
      numbers,
      "Input Manual",
      timeTaken,
      stats
    );

    await ctx.replyWithDocument(
      { source: filename },
      {
        caption: `📊 HASIL CEK ${numbers.length} NOMOR\n\n✅ Terdaftar   : ${stats.terdaftar}\n❌ Tidak       : ${stats.tidak}\n📝 Dengan bio  : ${stats.withBio}\n🏢 Business    : ${stats.business}\n⏱️ Waktu       : ${formatTime(timeTaken)}`,
        parse_mode: "Markdown"
      }
    );

    fs.unlinkSync(filename);

  } catch (err) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>❌ Error: ${err.message}</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

// ========== CEK FILE COMMAND ==========
bot.command("cekfile", checkPremium, async (ctx) => {
  if (!waConnected) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ WA Belum Terhubung!</b></blockquote>"
    );
  }

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Reply Ke File .txt</b></blockquote>"
    );
  }

  const doc = ctx.message.reply_to_message.document;
  
  if (!doc.file_name.endsWith(".txt")) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Hanya File .txt</b></blockquote>"
    );
  }

  const msg = await ctx.replyWithHTML(
    "<blockquote><b>⏳ Download File...</b></blockquote>"
  );

  try {
    const file = await ctx.telegram.getFileLink(doc.file_id);
    const response = await axios.get(file.href, { responseType: "text" });

    const numbers = response.data
      .split("\n")
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .slice(0, CONFIG.MAX_NUMBERS * 4);

    const progressBar = createProgressBar(0, numbers.length);
    
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>⌛ Otw Cek 0/${numbers.length}</b>\n${progressBar}</blockquote>`,
      { parse_mode: "HTML" }
    );

    const startTime = Date.now();
    const { results, stats } = await checkBioWithProgress(
      numbers,
      ctx,
      msg.message_id,
      ctx.chat.id
    );
    
    const timeTaken = Date.now() - startTime;

    let finalResult = `📊 HASIL CEK ${numbers.length} NOMOR\n\n`;
    finalResult += `✅ Terdaftar   : ${stats.terdaftar}\n`;
    finalResult += `❌ Tidak       : ${stats.tidak}\n`;
    finalResult += `📝 Dengan bio  : ${stats.withBio}\n`;
    finalResult += `🏢 Business    : ${stats.business}\n`;
    finalResult += `⏱️ Waktu       : ${formatTime(timeTaken)}`;

    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      finalResult,
      { parse_mode: "Markdown" }
    );

    const filename = generateResultFile(
      results,
      numbers,
      `File ${doc.file_name}`,
      timeTaken,
      stats
    );

    await ctx.replyWithDocument(
      { source: filename },
      {
        caption: `📊 HASIL CEK ${numbers.length} NOMOR\n\n✅ Terdaftar   : ${stats.terdaftar}\n❌ Tidak       : ${stats.tidak}\n📝 Dengan bio  : ${stats.withBio}\n🏢 Business    : ${stats.business}\n⏱️ Waktu       : ${formatTime(timeTaken)}`,
        parse_mode: "Markdown"
      }
    );

    fs.unlinkSync(filename);

  } catch (err) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>❌ Error: ${err.message}</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

// ========== IVAS COMMAND ==========
let ivasCache = {
  data: null,
  timestamp: 0,
  cacheTime: 5 * 60 * 1000
};

async function getIvasData() {
  const now = Date.now();
  
  if (ivasCache.data && (now - ivasCache.timestamp) < ivasCache.cacheTime) {
    return ivasCache.data;
  }
  
  try {
    const response = await axios.get(
      "https://ws.websocket.web.id/api/cekivas?platform=whatsapp",
      { timeout: 10000 }
    );
    
    if (response.data && response.data.success) {
      ivasCache.data = response.data;
      ivasCache.timestamp = now;
      return response.data;
    }
    
    throw new Error("Invalid response");
    
  } catch (error) {
    if (ivasCache.data) {
      return ivasCache.data;
    }
    throw error;
  }
}

bot.command("ivas", async (ctx) => {
  const msg = await ctx.replyWithHTML(
    "<blockquote><b>⏳ Mengambil Data IVAS...</b></blockquote>"
  );
  
  try {
    const data = await getIvasData();
    
    let hasil = "✦ CEK IVAS WHATSAPP ✦\n";
    hasil += `Total Sms : ${data.total_found}\n\n`;
    
    const sortedResults = data.results.sort((a, b) => b.count - a.count);
    
    for (let i = 0; i < Math.min(sortedResults.length, 20); i++) {
      hasil += `${i + 1}. ${sortedResults[i].country} ${sortedResults[i].count}\n`;
    }
    
    const date = new Date();
    const formattedDate = date.toLocaleString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    hasil += `\n\n⏱️ Update: ${formattedDate}`;
    
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote><b>${hasil}</b></blockquote>`,
      { parse_mode: "HTML" }
    );
    
  } catch (error) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      "<blockquote><b>❌ Gagal Mengambil Data!</b></blockquote>",
      { parse_mode: "HTML" }
    );
  }
});

// ========== PREMIUM COMMANDS ==========
bot.command("addprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  
  if (args.length < 2) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Format: /addprem user_id</b></blockquote>"
    );
  }
  
  const userId = args[1];
  
  if (!premiumUsers.includes(userId)) {
    premiumUsers.push(userId);
    savePremium();
    
    ctx.replyWithHTML(
      `<blockquote><b>✅ User <code>${userId}</code> Jadi Premium!</b></blockquote>`,
      backButton
    );
    
  } else {
    ctx.replyWithHTML(
      "<blockquote><b>⚠️ User Sudah Premium</b></blockquote>",
      backButton
    );
  }
});

bot.command("delprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");
  
  if (args.length < 2) {
    return ctx.replyWithHTML(
      "<blockquote><b>❌ Format: /delprem user_id</b></blockquote>"
    );
  }
  
  const userId = args[1];
  const index = premiumUsers.indexOf(userId);
  
  if (index > -1) {
    premiumUsers.splice(index, 1);
    savePremium();
    
    ctx.replyWithHTML(
      `<blockquote><b>✅ User <code>${userId}</code> Dihapus Dari Premium</b></blockquote>`,
      backButton
    );
    
  } else {
    ctx.replyWithHTML(
      "<blockquote><b>❌ User Tidak Ditemukan</b></blockquote>",
      backButton
    );
  }
});

bot.command("listprem", checkOwner, (ctx) => {
  if (premiumUsers.length === 0) {
    return ctx.replyWithHTML(
      "<blockquote><b>📭 Belum Ada Premium</b></blockquote>",
      backButton
    );
  }
  
  let msg = "<blockquote><b>💎 PREMIUM USERS</b>\n\n";
  
  premiumUsers.forEach((id, i) => {
    msg += `${i + 1}. <code>${id}</code>\n`;
  });
  
  msg += "</blockquote>";
  
  ctx.replyWithHTML(msg, backButton);
});

// ========== START BOT ==========
startWhatsApp();
bot.launch();

console.log(chalk.green(ASCII_ART));
console.log(chalk.green(`
╔══════════════════════════════╗
║   🔥 WA BIO CHECKER 🔥       ║
║   👑 Creator: ${CONFIG.CREATOR}   ║
║   💀 PREMAN DIGITAL INDONESIA ║
╚══════════════════════════════╝
`));

console.log(chalk.green(`✅ Bot started!`));
console.log(chalk.cyan(`👤 Owner ID: ${CONFIG.OWNER_IDS[0]}`));
console.log(chalk.cyan(`💎 Premium: ${premiumUsers.length}`));
console.log(chalk.cyan(`👥 Users: ${registeredUsers.length}`));

process.once("SIGINT", () => {
  console.log(chalk.red("\n🛑 Shutting down..."));
  bot.stop("SIGINT");
  process.exit(0);
});