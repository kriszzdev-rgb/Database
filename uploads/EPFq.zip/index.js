// SCRIPT CPANEL DARZ - FULL CODE FIXED
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const settings = require('./settings');
const tempUpdates = {};

// Konfigurasi Bot
const botToken = settings.token;
const owner = settings.owner;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumID.json';
const thumbnail = './image/thumbnail.png';
const pterodactyl = './image/pterodactyl.png';

// Inisialisasi Variabel
let premiumUsers = [];
let adminUsers = [];
let botStatus = 'running'; // running, stopped
let botStoppedBy = null;
let botStoppedTime = null;

// Baca file dengan error handling
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
    premiumUsers = [];
    fs.writeFileSync(premiumUsersFile, JSON.stringify([]));
}

try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
    adminUsers = [];
    fs.writeFileSync(adminfile, JSON.stringify([]));
}

// Inisialisasi Bot
const bot = new TelegramBot(botToken, { 
    polling: true,
    request: {
        timeout: 60000,
        agentOptions: {
            keepAlive: true,
            family: 4
        }
    }
});

// Bot Info
const nama = 'darz';
const author = 'darz';
const version = '3.0';
const startTime = Date.now();

// Utility Functions
const ALLOWED_GROUP_ID = -1002682347653; // ganti dengan ID grup lo

// Fungsi cek grup
function checkGroup(msg) {
    const chatId = msg.chat.id;

    if (chatId !== ALLOWED_GROUP_ID) {
        bot.sendMessage(chatId, `Gunakan di grup ress panel, sekali lagi melanggar gw kick no reff.\nGak ada akses? beli @kriszzyy`);
        return false;
    }
    return true;
}

function getRunDuration(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}

function generatePassword(length = 6) {
    const chars = "1234567890";
    let pass = "";
    for (let i = 0; i < length; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pass;
}

// Helper Functions untuk Validasi - DIPERBAIKI
function isAdmin(userId) {
    if (!userId || !settings.owner) {
        console.log('isAdmin: Missing userId or owner');
        return false;
    }
    try {
        const userIdStr = userId.toString();
        const ownerStr = settings.owner.toString();
        
        console.log('isAdmin check:', {
            userId: userIdStr,
            owner: ownerStr,
            adminUsers: adminUsers,
            isInAdminList: adminUsers.includes(userIdStr),
            isOwner: userIdStr === ownerStr
        });
        
        return adminUsers.includes(userIdStr) || userIdStr === ownerStr;
    } catch (error) {
        console.error('Error in isAdmin:', error);
        return false;
    }
}

function isOwner(userId) {
    if (!userId || !settings.owner) return false;
    try {
        return userId.toString() === settings.owner.toString();
    } catch (error) {
        console.error('Error in isOwner:', error);
        return false;
    }
}

function isValidUser(userId) {
    if (!userId) return false;
    const userIdStr = userId.toString();
    return premiumUsers.includes(userIdStr) || isAdmin(userIdStr);
}

// Function untuk cek akses menu
function checkMenuAccess(userId, menuName) {
    if (!isAdmin(userId)) {
        return {
            allowed: false,
            message: `❌ <b>Menu ${menuName} hanya untuk admin!</b>\n\nSilakan hubungi admin untuk akses menu ini.`
        };
    }
    return { allowed: true };
}

// Panel Functions dengan error handling yang lebih baik
async function checkUser(domainX, apiKey, username) {
    try {
        console.log(`Checking user ${username} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/users?filter[username]=${username}`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            timeout: 30000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error checking user:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

async function createUser(domainX, apiKey, username, password, rootAdmin = false) {
    try {
        console.log(`Creating user ${username} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                email: `${username}@gmail.com`,
                username: username,
                first_name: username,
                last_name: "Member",
                language: "en",
                root_admin: rootAdmin,
                password: password,
            }),
            timeout: 30000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error creating user:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

async function createServerSimple(domainX, apiKey, userId, serverName, ram, disk, eggId, locId, image) {
    try {
        console.log(`Creating server for user ${userId} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                name: serverName,
                description: `Server created by Bot Panel - ${new Date().toLocaleDateString('id-ID')}`,
                user: userId,
                egg: eggId,
                docker_image: image,
                startup: `if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}`,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start",
                    NODE_PACKAGES: "",
                    UNNODE_PACKAGES: ""
                },
                limits: {
                    memory: ram,
                    swap: 0,
                    disk: disk,
                    io: 500,
                    cpu: 0,
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 1,
                },
                deploy: {
                    locations: [parseInt(locId)],
                    dedicated_ip: false,
                    port_range: [],
                },
            }),
            timeout: 60000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error creating server:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

function checkAccess(userId, chatType, commandName) {
    if (chatType === "private") {
        const userIdStr = userId.toString();
        
        if (settings.owner) {
            // Kirim peringatan ke semua admin
            adminUsers.forEach((admin) => {
                if (admin && admin.toString) {
                    try {
                        bot.sendMessage(
                            admin,
                            `🚨 <b>PERINGATAN AKSES PV!</b>\n👤 <a href="tg://user?id=${userId}">User ID: ${userId}</a> mencoba menggunakan command <b>/${commandName}</b> di Private Message!\n\n⚠️ Command panel hanya boleh digunakan di grup.`,
                            { parse_mode: "HTML" }
                        );
                    } catch (error) {
                        console.error('Failed to send warning to admin:', error);
                    }
                }
            });
            
            // Kirim ke owner jika belum termasuk di adminUsers
            const ownerStr = settings.owner.toString();
            if (ownerStr !== userIdStr) {
                try {
                    bot.sendMessage(
                        settings.owner,
                        `🚨 <b>PERINGATAN AKSES PV!</b>\n👤 <a href="tg://user?id=${userId}">User ID: ${userId}</a> mencoba menggunakan command <b>/${commandName}</b> di Private Message!\n\n⚠️ Command panel hanya boleh digunakan di grup.`,
                        { parse_mode: "HTML" }
                    );
                } catch (error) {
                    console.error('Failed to send warning to owner:', error);
                }
            }
        } else {
            console.error('Settings.owner is undefined!');
        }
        
        return false;
    }
    return true;
}

// Handle Panel Creation dengan cek start bot di PV
async function handlePanelCreation(query) {
    const data = query.data;
    if (!data.startsWith("make_srv")) return;

    const parts = data.split("_");
    if (parts.length < 5) {
        return bot.answerCallbackQuery(query.id, { 
            text: "❌ Format callback data salah!", 
            show_alert: true 
        });
    }

    const srv = parts[1];
    const username = parts[2];
    const paket = parts[3];
    const password = parts.slice(4).join("_");

    let domainX, apiKey;
    if (srv === "srv1") { 
        domainX = settings.domain; 
        apiKey = settings.plta; 
    } else if (srv === "srv2") { 
        domainX = settings.domain2; 
        apiKey = settings.plta2; 
    } else if (srv === "srv3") { 
        domainX = settings.domain3; 
        apiKey = settings.plta3; 
    }

    if (!domainX || !apiKey) {
        return bot.sendMessage(query.message.chat.id, 
            `❌ Konfigurasi ${srv.toUpperCase()} belum lengkap! Hubungi admin.`
        );
    }

    try {
        await bot.editMessageText(`⏳ Sedang membuat panel ${paket.toUpperCase()} untuk ${username}...`, {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id
        });

        const check = await checkUser(domainX, apiKey, username);
        
        if (check.errors) {
            console.error('User check error:', check.errors);
            return bot.editMessageText(
                `❌ Error cek user: ${check.errors[0]?.detail || 'Unknown error'}`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id
                }
            );
        }
        
        if (check.data && check.data.length > 0) {
            return bot.editMessageText(
                `❌ Username <b>${username}</b> sudah dipakai di ${srv.toUpperCase()}!`, 
                { 
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: "HTML" 
                }
            );
        }

        const rootAdmin = paket === "admin";
        const userRes = await createUser(domainX, apiKey, username, password, rootAdmin);
        
        if (userRes.errors) {
            console.error('User creation error:', userRes.errors);
            return bot.editMessageText(
                `❌ Error membuat user: ${userRes.errors[0]?.detail || 'Unknown error'}`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id
                }
            );
        }

        const user = userRes.attributes;

        if (!rootAdmin) {
            let ram = 0, disk = 0;
            if (paket !== "unli") {
                ram = parseInt(paket.replace("gb", "")) * 1024;
                disk = ram * 2;
            }
            
            const eggId = settings.eggs || 15;
            const locId = settings.loc || 1;
            const image = "ghcr.io/parkervcp/yolks:nodejs_18";

            const serverRes = await createServerSimple(domainX, apiKey, user.id, username, ram, disk, eggId, locId, image);
            
            if (serverRes.errors) {
                console.error('Server creation error:', serverRes.errors);
                // Tetap lanjut meski server gagal, karena user sudah dibuat
                console.log('Server creation failed but user created successfully');
            }
        }

        const detailMsg = `
✅ <b>Panel Berhasil Dibuat</b>

📡 <b>Server:</b> ${srv.toUpperCase()}
👤 <b>Username:</b> <code>${user.username}</code>
🔐 <b>Password:</b> <code>${password}</code>
📦 <b>Paket:</b> ${paket.toUpperCase()}
🌐 <b>Login:</b> <a href="${domainX}">${domainX}</a>
${rootAdmin ? "\n⚠️ <b>Role: Admin Panel</b>" : ""}

<b>📌 RULES PANEL:</b>
- Dilarang DDOS / nyolong / ngintip panel lain
- Jangan buat panel kalau tidak dipakai
- Jangan jual terlalu murah
- Jangan sebarkan panel gratisan

❗ Melanggar aturan = kick + no all reff!

<i>Powered by @NoziKamiya</i>
        `;
        
        try {
            await bot.sendPhoto(query.from.id, pterodactyl, {
  caption: detailMsg,
  parse_mode: "HTML"
});
        } catch (error) {
            // PERINGATAN JIKA BELUM START DI PV
            return bot.editMessageText(
                `⚠️ <b>Panel berhasil dibuat tetapi tidak bisa mengirim detail ke PV Anda!</b>\n\n` +
                `📝 <b>SOLUSI:</b>\n` +
                `1. Klik tombol dibawah untuk start bot di PV\n` +
                `2. Atau ketik <code>/start</code> di PV bot\n` +
                `3. Setelah itu coba buat panel lagi\n\n` +
                `🔗 <a href="https://t.me/${bot.options.username}">Start Bot di PV</a>`,
                { 
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { 
                                    text: "🚀 START BOT DI PV", 
                                    url: `https://t.me/${bot.options.username}?start=start` 
                                }
                            ],
                            [
                                { 
                                    text: "🔄 COBA LAGI", 
                                    callback_data: `make_${srv}_${username}_${paket}_${password}` 
                                }
                            ]
                        ]
                    }
                }
            );
        }

        const ownerMsg = `
📢 <b>PANEL BARU DIBUAT</b>

👤 <b>Pembuat:</b> <a href="tg://user?id=${query.from.id}">${query.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${query.from.id}</code>
📋 <b>Username Panel:</b> <code>${username}</code>
📦 <b>Paket:</b> ${paket.toUpperCase()}
📡 <b>Server:</b> ${srv.toUpperCase()}
🕐 <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}
        `;

        try {
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });

            adminUsers.forEach(async (adminId) => {
                if (adminId !== settings.owner.toString()) {
                    try {
                        await bot.sendMessage(adminId, ownerMsg, { parse_mode: "HTML" });
                    } catch (error) {
                        console.error(`Failed to send notification to admin ${adminId}:`, error);
                    }
                }
            });
        } catch (error) {
            console.error('Failed to send notifications:', error);
        }

        await bot.editMessageText(
            `✅ Panel <b>${paket.toUpperCase()}</b> untuk username <b>${username}</b> berhasil dibuat di <b>${srv.toUpperCase()}</b>.\n\n📱 Detail login telah dikirim ke PV Anda.`, 
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: "HTML"
            }
        );

        await bot.answerCallbackQuery(query.id, { text: "✅ Panel berhasil dibuat!" });

    } catch (err) {
        console.error('Panel creation error:', err);
        
        let errorMsg = "⚠️ Gagal membuat panel.";
        if (err.message) {
            if (err.message.includes('ECONNREFUSED')) {
                errorMsg = "❌ Tidak dapat terhubung ke server panel.";
            } else if (err.message.includes('timeout')) {
                errorMsg = "⏰ Timeout saat membuat panel.";
            } else {
                errorMsg = `❌ Error: ${err.message}`;
            }
        }

        try {
            await bot.editMessageText(errorMsg, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id
            });

            await bot.answerCallbackQuery(query.id, { text: "❌ Gagal membuat panel!", show_alert: true });
        } catch (editError) {
            console.error('Error editing message:', editError);
        }
    }
}

// Middleware untuk block command saat bot stopped
bot.on("text", (msg) => {
    // Skip jika message dari bot atau bukan text command
    if (msg.from.is_bot || !msg.text) return;

    // Skip jika bot running
    if (botStatus === 'running') return;

    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;

    const isUserAdmin = isAdmin(userId);
    
    // Izinkan command control bot untuk admin
    const allowedCommands = ['/startbot', '/stopbot', '/restart', '/status'];
    const isControlCommand = allowedCommands.some(cmd => msg.text.startsWith(cmd));
    
    if (!isUserAdmin && !isControlCommand) {
        bot.sendMessage(chatId, 
            '🛑 <b>Bot sedang dalam status STOPPED</b>\n\n' +
            '🤖 Bot saat ini tidak merespon command.\n' +
            '📝 <b>Status:</b> 🔴 STOPPED\n\n' +
            'Silakan hubungi admin untuk memulai bot kembali.',
            { parse_mode: 'HTML' }
        );
        return; // Block command
    }
});

// ==================== BOT COMMANDS ====================

// START Command
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;

    const caption = `
<blockquote>
✨ おい <b>${msg.from.first_name}!</b>  
私はボットです。<b>@darzBegginer</b> によるパネルを作成してください。  
下のメニューボタンを選択してください。 🚀

◇ ᴅᴇᴠᴇʟᴏᴘᴇʀ : <a href="https://t.me/zyyredxxfemaous">t.me/zyyredxxfemaous</a>  
◇ ʀᴇᴄᴏᴅᴇ : <a href="https://t.me/darzBegginer">t.me/darzBegginer</a>  
◇ ɴᴀᴍᴇ ʙᴏᴛ : <b>Bot Create Panel</b>  
◇ ᴠᴇʀsɪᴏɴ : <b>3.0</b>  

❓ 何か問題がございましたらご連絡ください 👉 <a href="https://t.me/darzBegginer">Owner</a>
</blockquote>
`;

    const mainKeyboard = {
        inline_keyboard: [
            [
                { text: '⚡ ᴄᴘᴀɴᴇʟ ᴍᴇɴᴜ', callback_data: 'cpanelmenu' },
                { text: '✨ ғᴜɴ ᴍᴇɴᴜ', callback_data: 'funmenu' },
            ],
            [
                { text: '👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ', callback_data: 'ownermenu' },
                { text: '💬 ᴍʏ ᴏᴡɴᴇʀ', url: 'https://t.me/darzBegginer' }
            ],
            [
                { text: '📢 ᴄʜᴀɴɴᴇʟ ᴡʜᴀᴛsᴀᴘᴘ', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }
            ]
        ]
    };

    bot.sendPhoto(chatId, thumbnail, {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: mainKeyboard
    });
});

// DONE Command dengan format helper
bot.onText(/\/done$/, (msg) => {
    const chatId = msg.chat.id;
    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan:</b> <code>/done NamaProduk,Harga,Status</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/done (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1].split(",");

    if (input.length < 3) {
        const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan:</b> <code>/done NamaProduk,Harga,Status</code>
        `;
        return bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
    }

    const produk = input[0].trim();
    const harga = input[1].trim();
    const status = input[2].trim();

    const tanggal = new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    const struk = `
✅✨ 𝐓𝐑𝐀𝐍𝐒𝐀𝐊𝐒𝐈 𝐃𝐎𝐍𝐄 ✨✅
Terima kasih sudah melakukan pembayaran 💙

┌───────────────────
📦 𝗕𝗮𝗿𝗮𝗻𝗴/𝗝𝗮𝘀𝗮 : ${produk}
💰 𝗛𝗮𝗿𝗴𝗮 : Rp ${harga}
💳 𝗦𝘁𝗮𝘁𝘂𝘀 : ${status} ✅
📅 𝗧𝗮𝗻𝗴𝗴𝗮𝗹 : ${tanggal}
└───────────────────

🚀 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 :
ᴡʜᴀᴛsᴀᴘᴘ : 088221845865
ᴛᴇʟᴇɢʀᴀᴍ : t.me/darzBegginer
✨ 𝐓𝐞𝐬𝐭𝐢𝐦𝐨𝐧𝐢 :
- ᴛᴇʟᴇɢʀᴀᴍ : t.me/TestiDarz
- ᴡʜᴀᴛsᴀᴘᴘ : https://whatsapp.com/channel/0029VakpH6q3QxS1DXW5HD3z

🚀 Selamat menggunakan layanan kami
✨ Semoga anda senang dengan produk/jasa dari kami`;

    bot.sendMessage(chatId, struk, { parse_mode: "HTML" });
});

// CEK ID Command
bot.onText(/\/cekid$/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username || msg.from.first_name;
    const id = msg.from.id;
    const text12 = `Halo @${sender}\nID Telegram Anda: ${id}\nFull Name Anda : ${sender}\n${chatId}`;
    
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'Darz Information & Free', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }, 
                    { text: 'ᴏᴡɴᴇʀ', url: 'https://t.me/darzBegginer' }
                ]
            ]
        }
    };
    
    bot.sendMessage(chatId, text12, { 
        parse_mode: 'Markdown', 
        reply_markup: keyboard 
    });
});

// PREMIUM PANEL Commands dengan format helper
const paketList = ["1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","9gb","10gb","unli"];

// Handler untuk command tanpa parameter
paketList.forEach((paket) => {
    bot.onText(new RegExp(`\\/${paket}$`), (msg) => {
        const chatId = msg.chat.id;
        const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan:</b> <code>/${paket} username</code>
        `;
        
        bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
    });
});

// Handler untuk command dengan parameter
paketList.forEach((paket) => {
    bot.onText(new RegExp(`\\/${paket} (.+)`), async (msg, match) => {
    if (!checkGroup(msg)) return;
        const chatId = msg.chat.id;
        const chatType = msg.chat.type;
        const username = match[1].trim();
        const userId = msg.from.id;

        // Validasi username
        if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
            return bot.sendMessage(chatId, 
                '❌ <b>Username tidak valid!</b>' +
                { parse_mode: "HTML" }
            );
        }

        if (!checkAccess(userId, chatType, paket)) {
            return bot.sendMessage(chatId, `❌ <b>AKSES DITOLAK!</b>\n\n⚠️ Command <b>/${paket}</b> hanya dapat digunakan di grup, bukan di Private Message.\n\n📢 Silakan gunakan command ini di grup yang diizinkan.`, {
                parse_mode: "HTML"
            });
        }

        const password = username + generatePassword(6);

        const keyboard = {
            inline_keyboard: [
                [
                    { text: "🚀 SERVER 1", callback_data: `make_srv1_${username}_${paket}_${password}` },
                    { text: "🚀 SERVER 2", callback_data: `make_srv2_${username}_${paket}_${password}` },
                    { text: "🚀 SERVER 3", callback_data: `make_srv3_${username}_${paket}_${password}` },
                ],
            ],
        };

        bot.sendMessage(chatId, `📋 Pilih server untuk membuat <b>${username}</b> [${paket.toUpperCase()}]`, {
            parse_mode: "HTML",
            reply_markup: keyboard,
        });
    });
});

//ADMIN PANEL Command dengan format helper
bot.onText(/\/cadp$/, (msg) => {
    const chatId = msg.chat.id;
    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan:</b> <code>/cadp username</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/cadp (.+)/, async (msg, match) => {
if (!checkGroup(msg)) return;
    const chatId = msg.chat.id;
    const chatType = msg.chat.type;
    const username = match[1].trim();
    const userId = msg.from.id;

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }
    
    // Validasi username
    if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
        return bot.sendMessage(chatId, 
            '❌ <b>Username tidak valid!</b>\n\n' +
            { parse_mode: "HTML" }
        );
    }

    const password = generatePassword(8);

    const keyboard = {
        inline_keyboard: [
            [
                { text: "🚀 SERVER 1", callback_data: `make_srv1_${username}_admin_${password}` },
                { text: "🚀 SERVER 2", callback_data: `make_srv2_${username}_admin_${password}` },
                { text: "🚀 SERVER 3", callback_data: `make_srv3_${username}_admin_${password}` },
            ],
        ],
    };

    bot.sendMessage(chatId, `📋 Pilih server untuk membuat Admin Panel <b>${username}</b>`, {
        parse_mode: "HTML",
        reply_markup: keyboard,
    });
});

// ==================== CALLBACK QUERY HANDLER ====================

bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const msgId = query.message.message_id;
    const data = query.data;
    const userId = query.from.id.toString();

    try {
        // PERBAIKAN: Cek settings.owner sebelum validasi
        if (!settings.owner) {
            return bot.answerCallbackQuery(query.id, {
                text: "❌ Bot configuration error!",
                show_alert: true
            });
        }

        console.log('Callback received:', data);

        // Answer callback query immediately
        await bot.answerCallbackQuery(query.id);

        // Handle panel creation - TIDAK PERLU VALIDASI ADMIN
        if (data.startsWith("make_srv")) {
            return handlePanelCreation(query);
        }

        // PERBAIKAN: Untuk update settings, validasi admin
        if (data.startsWith("update_plta_") || data.startsWith("update_pltc_") || data.startsWith("update_domain_")) {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya admin yang bisa update settings!",
                    show_alert: true
                });
            }

            const server = data.split("_")[2];
            const type = data.split("_")[1];
            
            tempUpdates[userId] = {
                type: type,
                server: server,
                step: 'awaiting_input'
            };
            
            let messageText = '';
            if (type === 'plta') {
                messageText = `🔧 <b>Update PLTA untuk ${server.toUpperCase()}</b>\n\nSilakan kirim API Key PLTA yang baru:\n\n📝 <b>Format:</b> <code>ptla_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n❌ Ketik /cancel untuk membatalkan`;
            } else if (type === 'pltc') {
                messageText = `🔧 <b>Update PLTC untuk ${server.toUpperCase()}</b>\n\nSilakan kirim API Key PLTC yang baru:\n\n📝 <b>Format:</b> <code>ptlc_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n❌ Ketik /cancel untuk membatalkan`;
            } else if (type === 'domain') {
                messageText = `🔧 <b>Update Domain untuk ${server.toUpperCase()}</b>\n\nSilakan kirim domain yang baru:\n\n📝 <b>Format:</b> <code>https://panel.domain.com</code>\n❌ Ketik /cancel untuk membatalkan`;
            }
            
            return bot.editMessageText(messageText, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: 'HTML'
            });
        }

        if (data === "cancel_update") {
            if (tempUpdates[userId]) {
                delete tempUpdates[userId];
            }
            return bot.editMessageText("❌ Update dibatalkan.", {
                chat_id: chatId,
                message_id: msgId
            });
        }

        // Handle menu navigation dengan validasi
        if (data === "cpanelmenu") {
            const caption = `
<blockquote>
👑𝐃𝐄𝐕𝐄𝐋𝐎𝐕𝐄𝐑 𝐌𝐄𝐍𝐔👑
╭─────────────⧽
│ ✧ : 𝐃𝐄𝐕𝐄𝐋𝐎𝐕𝐄𝐑:𝐘𝐎𝐍
│ ✧ : 𝐒𝐓𝐀𝐓𝐔𝐒:𝐎𝐍,
│ ✧ : 𝐀𝐍𝐓𝐈 𝐅𝐑𝐄𝐄
│ ✧ : 𝐀𝐍𝐓𝐈𝐀𝐃𝐃
│ ✧ : 𝐀𝐍𝐓𝐈 𝐊𝐀𝐒𝐈 𝐅𝐑𝐄𝐄
╰─────────────⧽
╭─ ⚡ <b>𝐂𝐑𝐄𝐀𝐓 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔</b> ⚡
│ 📦 /1gb [nama]
│ 📦 /2gb [nama]
│ 📦 /3gb [nama]
│ 📦 /4gb [nama]
│ 📦 /5gb [nama]
│ 📦 /6gb [nama]
│ 📦 /7gb [nama]
│ 📦 /8gb [nama]
│ 📦 /9gb [nama]
│ 📦 /10gb [nama]
│ 📦 /unli [nama]
│ 📦 /cadp [nama]
╰─────────────
╭─ ⚡ 𝐏𝐄𝐑𝐈𝐍𝐆𝐀𝐓𝐀𝐍 ⚡
│ ⚠️ USAH BIKIN PANEL KE PV
│ ⚠️ KETAHUAN BUAT KE PV
│ ⚠️/kick
╰─────────────
─ ⚡ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔⚡
│ 📦 /startbot
│ 📦 /stopbot  
│ 📦 /restart
│ 📦 /status
│ 👑 /listusr
│ 👑 /upplta
│ 👑 /uppltc
│ 👑 /updomain
╰────────────
👑𝐀𝐃𝐌𝐈𝐍 𝐌𝐄𝐍𝐔👑
╭─────────────⧽
│ ✧ /addowner [id tele]
│ ✧ /addprem [id tele]
│ ✧ /delowner [id tele]
│ ✧ /delprem [id tele]
│ ✧ /kick
│ ✧ /promote
│ ✧ /demote
╰─────────────⧽
</blockquote>

🗾 パネルV1メニュー (Panel Menu)
「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "funmenu") {
            const caption = `
<blockquote>
╭─ ✨ <b>FUN MENU</b> ✨
│ 🚀 /done [NamaProduk],[Nominal],[Status]
│ 🚀 /cekid
╰─────────────
</blockquote>

🗾 メニュー FUN (Fun Menu)
「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "ownermenu") {
            // PERBAIKAN: Gunakan fungsi validasi yang konsisten
            const accessCheck = checkMenuAccess(userId, "Owner");
            if (!accessCheck.allowed) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Menu hanya untuk admin!",
                    show_alert: true
                });
            }

            const caption = `
<blockquote>
╭─ 👑 <b>OWNER MENU</b> 👑
│ 🤖 /startbot
│ 🛑 /stopbot  
│ 🔄 /restart
│ 📊 /status
│ 🛠 /addowner [id tele]
│ 🛠 /addprem [id tele]
│ 🛠 /delowner [id tele]
│ 🛠 /delprem [id tele]
│ 🛠 /listusr
│ 🛠 /upplta
│ 🛠 /uppltc
│ 🛠 /updomain
╰─────────────
</blockquote>

🗡 オーナーのメニュー (Owner Command)
「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "back") {
            const mainCaption = `
<blockquote>
✨ おい <b>${query.from.first_name}!</b>  
私はボットです。<b>@darzBegginer</b> によるパネルを作成してください。  
下のメニューボタンを選択してください。 🚀

◇ ᴅᴇᴠᴇʟᴏᴘᴇʀ : <a href="https://t.me/zyyredxxfemaous">t.me/zyyredxxfemaous</a>  
◇ ʀᴇᴄᴏᴅᴇ : <a href="https://t.me/darzBegginer">t.me/darzBegginer</a>  
◇ ɴᴀᴍᴇ ʙᴏᴛ : <b>Bot Create Panel</b>  
◇ ᴠᴇʀsɪᴏɴ : <b>3.0</b>  

❓ 何か問題がございましたらご連絡ください 👉 <a href="https://t.me/darzBegginer">Owner</a>
</blockquote>
`;

            const mainKeyboard = {
                inline_keyboard: [
                    [
                        { text: '⚡ ᴄᴘᴀɴᴇʟ ᴍᴇɴᴜ', callback_data: 'cpanelmenu' },
                        { text: '✨ ғᴜɴ ᴍᴇɴᴜ', callback_data: 'funmenu' },
                    ],
                    [
                        { text: '👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ', callback_data: 'ownermenu' },
                        { text: '💬 ᴍʏ ᴏᴡɴᴇʀ', url: 'https://t.me/darzBegginer' }
                    ],
                    [
                        { text: '📢 ᴄʜᴀɴɴᴇʟ ᴡʜᴀᴛsᴀᴘᴘ', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }
                    ]
                ]
            };

            return bot.editMessageCaption(mainCaption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: mainKeyboard
            });
        }

        // ==================== BOT CONTROL HANDLERS ====================

        // Handle restart from callback
        if (data === "restart_bot") {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya owner dan admin yang bisa restart bot!",
                    show_alert: true
                });
            }

            await bot.answerCallbackQuery(query.id, { text: "🔄 Restarting bot..." });
            
            // Simulasikan command restart
            const fakeMsg = {
                chat: { id: query.message.chat.id, type: query.message.chat.type, title: query.message.chat.title },
                from: query.from,
                text: '/restart'
            };
            
            // Panggil handler restart
            bot.emit('text', fakeMsg);
            return;
        }

        // Handle debug settings from callback
        if (data === "debug_settings") {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya owner dan admin yang bisa akses!",
                    show_alert: true
                });
            }

            const debugInfo = `
🔧 <b>Debug Settings</b>

<b>Server 1:</b>
🌐 Domain: ${settings.domain || 'Not set'}
🔑 PLTA: ${settings.plta ? settings.plta.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc ? settings.pltc.substring(0, 10) + '...' : 'Not set'}

<b>Server 2:</b>
🌐 Domain: ${settings.domain2 || 'Not set'}
🔑 PLTA: ${settings.plta2 ? settings.plta2.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc2 ? settings.pltc2.substring(0, 10) + '...' : 'Not set'}

<b>Server 3:</b>
🌐 Domain: ${settings.domain3 || 'Not set'}
🔑 PLTA: ${settings.plta3 ? settings.plta3.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc3 ? settings.pltc3.substring(0, 10) + '...' : 'Not set'}

👑 Owner: ${settings.owner}
👥 Admins: ${adminUsers.length}
⭐ Premium: ${premiumUsers.length}
            `;

            return bot.editMessageText(debugInfo, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "🔄 Restart Bot", callback_data: "restart_bot" },
                            { text: "⬅️ Back to Status", callback_data: "back_to_status" }
                        ]
                    ]
                }
            });
        }

        // Handle back to status
        if (data === "back_to_status") {
            // Panggil command status
            const fakeMsg = {
                chat: { id: query.message.chat.id, type: query.message.chat.type, title: query.message.chat.title },
                from: query.from,
                text: '/status'
            };
            bot.emit('text', fakeMsg);
            return;
        }

        // If no handler found
        console.log('No handler for callback:', data);
        bot.answerCallbackQuery(query.id, { text: "⚠️ Opsi tidak dikenali!", show_alert: true });

    } catch (error) {
        console.error('Callback query error:', error);
        bot.answerCallbackQuery(query.id, { text: "❌ Terjadi kesalahan!", show_alert: true });
    }
});

// ==================== OWNER COMMANDS DENGAN BALAS PESAN ====================

// ADDOWNER Command dengan format helper dan balas pesan
bot.onText(/\/addowner$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    // PERBAIKAN: Tambahkan debug log
    console.log('addowner command called by:', userId);
    console.log('isAdmin check:', isAdmin(userId));
    console.log('adminUsers:', adminUsers);
    console.log('owner:', settings.owner);

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan salah satu:</b>
<code>/addowner user_id</code>
ATAU
Balas pesan user dengan <code>/addowner</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    // PERBAIKAN: Tambahkan debug log
    console.log('addowner with param called by:', userId);
    console.log('targetId:', targetId);
    console.log('isAdmin:', isAdmin(userId));

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '❌ <b>User ID tidak valid!</b>\n\n' +
            { parse_mode: "HTML" }
        );
    }

    // Cek jika user sudah menjadi admin
    if (adminUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `❌ <b>User sudah menjadi admin!</b>\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `📊 Status: Sudah admin`,
            { parse_mode: "HTML" }
        );
    }

    // Tambahkan ke admin
    adminUsers.push(targetId);
    fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

    bot.sendMessage(chatId, 
        `✅ <b>User berhasil ditambahkan sebagai admin!</b>\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `👑 Role: Admin Panel\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
        { parse_mode: "HTML" }
    );

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `👑 <b>ADMIN BARU DITAMBAHKAN</b>\n\n` +
            `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk addowner dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/addowner') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        // PERBAIKAN: Tambahkan debug log
        console.log('addowner reply called by:', userId);
        console.log('targetId:', targetId);
        console.log('isAdmin:', isAdmin(userId));

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user sudah menjadi admin
        if (adminUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `❌ <b>User sudah menjadi admin!</b>\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `📊 Status: Sudah admin`,
                { parse_mode: "HTML" }
            );
        }

        // Tambahkan ke admin
        adminUsers.push(targetId);
        fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

        bot.sendMessage(chatId, 
            `✅ <b>User berhasil ditambahkan sebagai admin!</b>\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `👑 Role: Admin Panel\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `👑 <b>ADMIN BARU DITAMBAHKAN</b>\n\n` +
                `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }

        // Coba kirim notifikasi ke user yang ditambahkan
        try {
            bot.sendMessage(targetId,
                `🎉 <b>SELAMAT!</b>\n\n` +
                `Anda telah ditambahkan sebagai <b>Admin Panel</b>!\n\n` +
                `👑 <b>Hak Akses:</b>\n` +
                `• Buat panel admin\n` +
                `• Manage user premium\n` +
                `• Control bot (start/stop/restart)\n` +
                `• Update settings panel\n\n` +
                `⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                `⚠️ <b>Note:</b> Gunakan akses dengan bijak!`,
                { parse_mode: "HTML" }
            );
        } catch (error) {
            console.error('Failed to send notification to new admin:', error);
        }
    }
});

// ADDPREM Command dengan format helper dan balas pesan
bot.onText(/\/addprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan salah satu:</b>
<code>/addprem user_id</code>
ATAU
Balas pesan user dengan <code>/addprem</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '❌ <b>User ID tidak valid!</b>\n\n' +
            '📝 <b>Format:</b> <code>/addprem 123456789</code>\n\n' +
            '🔍 <b>Atau balas pesan user dengan:</b> <code>/addprem</code>',
            { parse_mode: "HTML" }
        );
    }

    // Cek jika user sudah premium
    if (premiumUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `❌ <b>User sudah premium!</b>\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `⭐ Status: Sudah premium`,
            { parse_mode: "HTML" }
        );
    }

    // Tambahkan ke premium
    premiumUsers.push(targetId);
    fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

    bot.sendMessage(chatId, 
        `⭐ <b>User berhasil ditambahkan sebagai premium!</b>\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `🎯 Role: Premium User\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
        `✨ <b>Fitur yang didapat:</b>\n` +
        `• Akses semua command panel\n` +
        `• Priority support\n` +
        `• Dan lainnya...`,
        { parse_mode: "HTML" }
    );

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `⭐ <b>PREMIUM USER BARU</b>\n\n` +
            `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk addprem dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/addprem') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user sudah premium
        if (premiumUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `❌ <b>User sudah premium!</b>\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⭐ Status: Sudah premium`,
                { parse_mode: "HTML" }
            );
        }

        // Tambahkan ke premium
        premiumUsers.push(targetId);
        fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

        bot.sendMessage(chatId, 
            `⭐ <b>User berhasil ditambahkan sebagai premium!</b>\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `🎯 Role: Premium User\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
            `✨ <b>Fitur yang didapat:</b>\n` +
            `• Akses semua command panel\n` +
            `• Priority support\n` +
            `• Dan lainnya...`,
            { parse_mode: "HTML" }
        );

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `⭐ <b>PREMIUM USER BARU</b>\n\n` +
                `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }

        // Coba kirim notifikasi ke user yang ditambahkan
        try {
            bot.sendMessage(targetId,
                `🎉 <b>SELAMAT!</b>\n\n` +
                `Anda telah diupgrade menjadi <b>Premium User</b>!\n\n` +
                `⭐ <b>Fitur Premium:</b>\n` +
                `• Akses semua command panel (1GB - UNLI)\n` +
                `• Priority support\n` +
                `• Akses penuh ke semua server\n\n` +
                `⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                `Terima kasih telah menggunakan layanan kami! 🚀`,
                { parse_mode: "HTML" }
            );
        } catch (error) {
            console.error('Failed to send notification to new premium user:', error);
        }
    }
});

// DELOWNER Command dengan format helper dan balas pesan
bot.onText(/\/delowner$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan salah satu:</b>
<code>/delowner user_id</code>
ATAU
Balas pesan user dengan <code>/delowner</code>

    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '❌ <b>User ID tidak valid!</b>\n\n' +
            '📝 <b>Format:</b> <code>/delowner 123456789</code>\n\n' +
            '🔍 <b>Atau balas pesan user dengan:</b> <code>/delowner</code>',
            { parse_mode: "HTML" }
        );
    }

    // Cek jika target adalah owner utama
    if (targetId === settings.owner.toString()) {
        return bot.sendMessage(chatId, 
            '❌ <b>Tidak bisa menghapus owner utama!</b>\n\n' +
            '👑 Owner utama tidak dapat dihapus dari sistem.',
            { parse_mode: "HTML" }
        );
    }

    // Cek jika user adalah admin
    if (!adminUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `❌ <b>User bukan admin!</b>\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `📊 Status: Bukan admin`,
            { parse_mode: "HTML" }
        );
    }

    // Hapus dari admin
    adminUsers = adminUsers.filter(id => id !== targetId);
    fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

    bot.sendMessage(chatId, 
        `🗑️ <b>User berhasil dihapus dari admin!</b>\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `👑 Role: User Biasa\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
        { parse_mode: "HTML" }
    );

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `🗑️ <b>ADMIN DIHAPUS</b>\n\n` +
            `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk delowner dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/delowner') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika target adalah owner utama
        if (targetId === settings.owner.toString()) {
            return bot.sendMessage(chatId, 
                '❌ <b>Tidak bisa menghapus owner utama!</b>\n\n' +
                '👑 Owner utama tidak dapat dihapus dari sistem.',
                { parse_mode: "HTML" }
            );
        }

        // Cek jika user adalah admin
        if (!adminUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `❌ <b>User bukan admin!</b>\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `📊 Status: Bukan admin`,
                { parse_mode: "HTML" }
            );
        }

        // Hapus dari admin
        adminUsers = adminUsers.filter(id => id !== targetId);
        fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

        bot.sendMessage(chatId, 
            `🗑️ <b>User berhasil dihapus dari admin!</b>\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `👑 Role: User Biasa\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `🗑️ <b>ADMIN DIHAPUS</b>\n\n` +
                `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }
    }
});

// DELPREM Command dengan format helper dan balas pesan
bot.onText(/\/delprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
❌ <b>Format Salah!</b>

📝 <b>Gunakan salah satu:</b>
<code>/delprem user_id</code>
ATAU
Balas pesan user dengan <code>/delprem</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '❌ <b>User ID tidak valid!</b>\n\n' +
            '📝 <b>Format:</b> <code>/delprem 123456789</code>\n\n' +
            '🔍 <b>Atau balas pesan user dengan:</b> <code>/delprem</code>',
            { parse_mode: "HTML" }
        );
    }

    // Cek jika user adalah premium
    if (!premiumUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `❌ <b>User bukan premium!</b>\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `⭐ Status: Bukan premium`,
            { parse_mode: "HTML" }
        );
    }

    // Hapus dari premium
    premiumUsers = premiumUsers.filter(id => id !== targetId);
    fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

    bot.sendMessage(chatId, 
        `📉 <b>User berhasil dihapus dari premium!</b>\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `🎯 Role: User Biasa\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
        `⚠️ <b>User kehilangan akses:</b>\n` +
        `• Fitur premium panel\n` +
        `• Priority support`,
        { parse_mode: "HTML" }
    );

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `📉 <b>PREMIUM USER DIHAPUS</b>\n\n` +
            `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk delprem dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/delprem') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user adalah premium
        if (!premiumUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `❌ <b>User bukan premium!</b>\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⭐ Status: Bukan premium`,
                { parse_mode: "HTML" }
            );
        }

        // Hapus dari premium
        premiumUsers = premiumUsers.filter(id => id !== targetId);
        fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

        bot.sendMessage(chatId, 
            `📉 <b>User berhasil dihapus dari premium!</b>\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `🎯 Role: User Biasa\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
            `⚠️ <b>User kehilangan akses:</b>\n` +
            `• Fitur premium panel\n` +
            `• Priority support`,
            { parse_mode: "HTML" }
        );

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `📉 <b>PREMIUM USER DIHAPUS</b>\n\n` +
                `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }
    }
});

// LISTUSR Command
bot.onText(/\/listusr/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    let adminList = "<b>👑 Daftar Admin:</b>\n\n";
    adminUsers.forEach((id, i) => {
        adminList += `${i + 1}. <code>${id}</code>\n`;
    });

    let premiumList = "<b>⭐ Daftar Premium:</b>\n\n";
    premiumUsers.forEach((id, i) => {
        premiumList += `${i + 1}. <code>${id}</code>\n`;
    });

    const message = `${adminList}\n${premiumList}\n📊 <b>Total:</b> ${adminUsers.length} Admin, ${premiumUsers.length} Premium`;

    bot.sendMessage(chatId, message, { parse_mode: "HTML" });
});

// UPDATE SETTINGS Commands
// === Command Update PLTA ===
bot.onText(/\/upplta (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);

    // validasi admin
    if (userId !== String(owner) && !adminUsers.includes(userId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner/Admin!");
    }

    const newPlta = match[1].trim();

    const keyboard = {
        inline_keyboard: [
            [
                { text: "⚡ SRV 1", callback_data: `up_plta_srv1_${newPlta}` },
                { text: "⚡ SRV 2", callback_data: `up_plta_srv2_${newPlta}` },
                { text: "⚡ SRV 3", callback_data: `up_plta_srv3_${newPlta}` },
            ]
        ]
    };

    bot.sendMessage(chatId, `📋 Mau update <b>PLTA</b> menjadi <code>${newPlta}</code> di server mana?`, {
        parse_mode: "HTML",
        reply_markup: keyboard
    });
});

// === Callback handler untuk update PLTA ===
bot.on("callback_query", async (query) => {
    const data = query.data;
    if (data.startsWith("up_plta")) {
        const [, , srv, newPlta] = data.split("_");

        let key;
        if (srv === "srv1") key = "plta";
        else if (srv === "srv2") key = "plta2";
        else if (srv === "srv3") key = "plta3";

        if (!key) return bot.answerCallbackQuery(query.id, { text: "❌ Server tidak valid!" });

        // update settings.js secara dinamis
        settings[key] = newPlta;
        fs.writeFileSync('./settings.js', `module.exports = ${JSON.stringify(settings, null, 2)}`);

        bot.editMessageText(`✅ Berhasil update <b>PLTA</b> di ${srv.toUpperCase()} → <code>${newPlta}</code>`, {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            parse_mode: "HTML"
        });

        return bot.answerCallbackQuery(query.id, { text: "✅ PLTA berhasil diupdate!" });
    }
});

// DEBUG SETTINGS Command
bot.onText(/\/debugsettings$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const debugInfo = `
🔧 <b>Debug Settings</b>

<b>Server 1:</b>
🌐 Domain: ${settings.domain || 'Not set'}
🔑 PLTA: ${settings.plta ? settings.plta.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc ? settings.pltc.substring(0, 10) + '...' : 'Not set'}

<b>Server 2:</b>
🌐 Domain: ${settings.domain2 || 'Not set'}
🔑 PLTA: ${settings.plta2 ? settings.plta2.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc2 ? settings.pltc2.substring(0, 10) + '...' : 'Not set'}

<b>Server 3:</b>
🌐 Domain: ${settings.domain3 || 'Not set'}
🔑 PLTA: ${settings.plta3 ? settings.plta3.substring(0, 10) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc3 ? settings.pltc3.substring(0, 10) + '...' : 'Not set'}

👑 Owner: ${owner}
👥 Admins: ${adminUsers.length}
⭐ Premium: ${premiumUsers.length}

📊 Temp Updates: ${Object.keys(tempUpdates).length}
    `;

    bot.sendMessage(chatId, debugInfo, { parse_mode: 'HTML' });
});

// STATUS Command
bot.onText(/\/status$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!settings.owner) {
        return bot.sendMessage(chatId, 
            '❌ <b>Error: Owner not configured!</b>\n\nSilakan cek file settings.js.',
            { parse_mode: 'HTML' }
        );
    }

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    const memoryUsage = process.memoryUsage();
    const statusMessage = `
🤖 <b>BOT STATUS</b>

📊 <b>System Info:</b>
├─ 🕒 <b>Uptime:</b> ${getRunDuration(startTime)}
├─ 📈 <b>Memory Usage:</b> ${(memoryUsage.rss / 1024 / 1024).toFixed(2)} MB
├─ 🔄 <b>Node.js:</b> ${process.version}
├─ 📁 <b>Platform:</b> ${process.platform}
└─ 🏃 <b>PID:</b> ${process.pid}

👥 <b>User Statistics:</b>
├─ 👑 <b>Owner:</b> <code>${settings.owner}</code>
├─ 🔧 <b>Admins:</b> ${adminUsers.length} users
└─ ⭐ <b>Premium:</b> ${premiumUsers.length} users

🌐 <b>Server Status:</b>
├─ 🚀 <b>SRV1:</b> ${settings.domain && settings.domain !== '-' ? '✅' : '❌'}
├─ 🚀 <b>SRV2:</b> ${settings.domain2 && settings.domain2 !== '-' ? '✅' : '❌'}
└─ 🚀 <b>SRV3:</b> ${settings.domain3 && settings.domain3 !== '-' ? '✅' : '❌'}

⏰ <b>Start Time:</b> ${new Date(startTime).toLocaleString('id-ID')}
🔄 <b>Last Restart:</b> ${new Date().toLocaleString('id-ID')}
📝 <b>Bot Status:</b> ${botStatus === 'running' ? '🟢 RUNNING' : '🔴 STOPPED'}

<i>Gunakan /restart untuk restart bot</i>
    `;

    bot.sendMessage(chatId, statusMessage, { 
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "🔄 Restart Bot", callback_data: "restart_bot" },
                    { text: "📊 Debug Settings", callback_data: "debug_settings" }
                ]
            ]
        }
    });
});

// START BOT Command
bot.onText(/\/startbot$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    // Jika bot sudah running
    if (botStatus === 'running') {
        return bot.sendMessage(chatId, 
            '✅ <b>Bot sudah dalam status RUNNING</b>\n\n' +
            '🤖 Bot sedang berjalan normal.\n' +
            '🕒 <b>Uptime:</b> ' + getRunDuration(startTime),
            { parse_mode: 'HTML' }
        );
    }

    try {
        // Start bot
        botStatus = 'running';
        botStoppedBy = null;
        botStoppedTime = null;

        const startMessage = `
🚀 <b>Starting Bot...</b>

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
📍 <b>Chat:</b> ${msg.chat.type === 'private' ? 'Private' : msg.chat.title || 'Group'}

<i>Bot sedang memulai...</i>
        `;

        const sentMsg = await bot.sendMessage(chatId, startMessage, { 
            parse_mode: "HTML" 
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🚀 <b>BOT STARTED</b>

👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
📍 <b>Chat:</b> ${msg.chat.type === 'private' ? 'Private' : msg.chat.title || 'Group'}
            `;
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Kirim ke semua admin
        const adminMsg = `
🚀 <b>BOT STARTED</b>

👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}
        `;

        adminUsers.forEach(async (adminId) => {
            if (adminId !== userId && settings.owner && adminId !== settings.owner.toString()) {
                try {
                    await bot.sendMessage(adminId, adminMsg, { parse_mode: "HTML" });
                } catch (error) {
                    console.error(`Failed to send start notification to admin ${adminId}:`, error);
                }
            }
        });

        // Update message setelah start
        setTimeout(async () => {
            try {
                await bot.editMessageText(
                    '✅ <b>Bot successfully STARTED!</b>\n\n' +
                    '🤖 Bot sekarang aktif dan siap melayani.\n' +
                    '🕒 <b>Uptime:</b> ' + getRunDuration(startTime) + '\n' +
                    '📊 <b>Status:</b> 🟢 RUNNING',
                    {
                        chat_id: chatId,
                        message_id: sentMsg.message_id,
                        parse_mode: "HTML"
                    }
                );
            } catch (error) {
                console.error('Error editing start message:', error);
            }
        }, 2000);

    } catch (error) {
        console.error('Start command error:', error);
        bot.sendMessage(chatId, '❌ Gagal memulai bot!');
    }
});

// RESTART Command
bot.onText(/\/restart$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    const restartMessage = `
🔄 <b>Restarting Bot...</b>

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Requested by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}

<i>Bot akan restart dalam 3 detik...</i>
    `;

    bot.sendMessage(chatId, restartMessage, { 
        parse_mode: "HTML" 
    }).then(() => {
        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🔁 <b>BOT RESTART REQUEST</b>

👤 <b>Requested by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
📍 <b>Chat:</b> ${msg.chat.type === 'private' ? 'Private' : msg.chat.title || 'Group'}
            `;
            bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Delay sebelum restart
        setTimeout(() => {
            console.log(`🔄 Bot restart requested by ${userId} at ${new Date().toLocaleString('id-ID')}`);
            process.exit(0); // Exit dengan code 0 untuk restart
        }, 3000);
    });
});

// STOP BOT Command
bot.onText(/\/stopbot$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    // Jika bot sudah stopped
    if (botStatus === 'stopped') {
        return bot.sendMessage(chatId, 
            '❌ <b>Bot sudah dalam status STOPPED</b>\n\n' +
            `🛑 <b>Stopped by:</b> <code>${botStoppedBy || 'Unknown'}</code>\n` +
            `⏰ <b>Since:</b> ${botStoppedTime ? new Date(botStoppedTime).toLocaleString('id-ID') : 'Unknown'}\n\n` +
            'Gunakan <code>/startbot</code> untuk memulai bot kembali.',
            { parse_mode: 'HTML' }
        );
    }

    try {
        const stopMessage = `
🛑 <b>Stopping Bot...</b>

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}
📍 <b>Chat:</b> ${msg.chat.type === 'private' ? 'Private' : msg.chat.title || 'Group'}

⚠️ <b>Bot akan berhenti merespon command!</b>

<i>Gunakan /startbot untuk memulai kembali</i>
        `;

        const sentMsg = await bot.sendMessage(chatId, stopMessage, { 
            parse_mode: "HTML" 
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🛑 <b>BOT STOPPED</b>

👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}
📍 <b>Chat:</b> ${msg.chat.type === 'private' ? 'Private' : msg.chat.title || 'Group'}
            `;
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Kirim ke semua admin
        const adminMsg = `
🛑 <b>BOT STOPPED</b>

👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Last Uptime:</b> ${getRunDuration(startTime)}
        `;

        adminUsers.forEach(async (adminId) => {
            if (adminId !== userId && settings.owner && adminId !== settings.owner.toString()) {
                try {
                    await bot.sendMessage(adminId, adminMsg, { parse_mode: "HTML" });
                } catch (error) {
                    console.error(`Failed to send stop notification to admin ${adminId}:`, error);
                }
            }
        });

        // Update status bot
        botStatus = 'stopped';
        botStoppedBy = userId;
        botStoppedTime = Date.now();

        // Update message setelah stop
        setTimeout(async () => {
            try {
                await bot.editMessageText(
                    '🛑 <b>Bot successfully STOPPED!</b>\n\n' +
                    '🤖 Bot berhenti merespon command.\n' +
                    `👤 <b>Stopped by:</b> <code>${userId}</code>\n` +
                    `⏰ <b>Stopped at:</b> ${new Date().toLocaleString('id-ID')}\n` +
                    `🕒 <b>Last Uptime:</b> ${getRunDuration(startTime)}\n\n` +
                    '📝 <b>Status:</b> 🔴 STOPPED\n\n' +
                    'Gunakan <code>/startbot</code> untuk memulai bot kembali.',
                    {
                        chat_id: chatId,
                        message_id: sentMsg.message_id,
                        parse_mode: "HTML"
                    }
                );
            } catch (error) {
                console.error('Error editing stop message:', error);
            }
        }, 2000);

    } catch (error) {
        console.error('Stop command error:', error);
        bot.sendMessage(chatId, '❌ Gagal menghentikan bot!');
    }
});

// ==================== MESSAGE HANDLER FOR UPDATE SETTINGS ====================

bot.on("message", async (msg) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;
    const text = msg.text ? msg.text.trim() : '';

    // Skip jika message dari bot atau command
    if (msg.from.is_bot || text.startsWith('/')) {
        return;
    }

    // Check jika user sedang dalam proses update settings
    if (tempUpdates[userId] && tempUpdates[userId].step) {
        const userData = tempUpdates[userId];

        // Handle cancel
        if (text === '/cancel') {
            delete tempUpdates[userId];
            return bot.sendMessage(chatId, "❌ Update dibatalkan.");
        }

        try {
            // Baca settings file
            let settingsContent;
            try {
                settingsContent = fs.readFileSync('./settings.js', 'utf8');
            } catch (error) {
                console.error('Error reading settings:', error);
                return bot.sendMessage(chatId, "❌ Error membaca file settings!");
            }

            let newContent = settingsContent;
            let successMessage = '';

            if (userData.type === 'plta' || userData.type === 'pltc') {
                // Validasi API Key
                const isValidPlta = text.startsWith('ptla_') && text.length >= 30;
                const isValidPltc = text.startsWith('ptlc_') && text.length >= 30;
                const isValidGeneric = text.startsWith('eyJ') && text.length >= 50;
                
                if (!isValidPlta && !isValidPltc && !isValidGeneric) {
                    return bot.sendMessage(chatId, 
                        "❌ Format API Key tidak valid!\n\n" +
                        "📝 Format yang diterima:\n" +
                        "• PLTA: <code>ptla_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n" +
                        "• PLTC: <code>ptlc_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n" +
                        "• JWT: <code>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</code>\n\n" +
                        "Silakan coba lagi atau ketik /cancel untuk membatalkan:",
                        { parse_mode: 'HTML' }
                    );
                }

                // Tentukan nama setting
                let settingName;
                if (userData.type === 'plta') {
                    settingName = userData.server === 'srv1' ? 'plta' : 
                                 userData.server === 'srv2' ? 'plta2' : 'plta3';
                } else {
                    settingName = userData.server === 'srv1' ? 'pltc' : 
                                 userData.server === 'srv2' ? 'pltc2' : 'pltc3';
                }
                
                // Update settings
                const regex = new RegExp(`(${settingName}:\\s*)['"][^'"]*['"]`, 'g');
                newContent = settingsContent.replace(regex, `$1'${text}'`);
                
                successMessage = `✅ <b>${userData.type.toUpperCase()} untuk ${userData.server.toUpperCase()} berhasil diupdate!</b>\n\n🔑 Key: <code>${text.substring(0, 15)}...</code>`;

            } else if (userData.type === 'domain') {
                // Validasi Domain
                const domainRegex = /^https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
                if (!domainRegex.test(text)) {
                    return bot.sendMessage(chatId, 
                        "❌ Format domain salah!\n\n" +
                        "📝 Format yang benar:\n" +
                        "• <code>https://panel.domain.com</code>\n" +
                        "• <code>http://localhost:8080</code>\n\n" +
                        "Silakan coba lagi atau ketik /cancel untuk membatalkan:",
                        { parse_mode: 'HTML' }
                    );
                }

                // Tentukan nama setting
                const settingName = userData.server === 'srv1' ? 'domain' : 
                                   userData.server === 'srv2' ? 'domain2' : 'domain3';
                
                // Update settings
                const regex = new RegExp(`(${settingName}:\\s*)['"][^'"]*['"]`, 'g');
                newContent = settingsContent.replace(regex, `$1'${text}'`);
                
                successMessage = `✅ <b>Domain untuk ${userData.server.toUpperCase()} berhasil diupdate!</b>\n\n🌐 Domain: <code>${text}</code>`;
            }

            // Tulis perubahan ke file
            fs.writeFileSync('./settings.js', newContent);
            
            // Kirim pesan sukses
            bot.sendMessage(chatId, successMessage + "\n\n🔄 Restart bot untuk menerapkan perubahan.", {
                parse_mode: 'HTML'
            });

            // Hapus data temporary setelah selesai
            delete tempUpdates[userId];

        } catch (error) {
            console.error('Update settings error:', error);
            bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengupdate settings!");
            delete tempUpdates[userId];
        }
    }
});

// ==================== ERROR HANDLING ====================

bot.on("polling_error", (error) => {
    console.error('Polling error:', error);
});

bot.on("error", (error) => {
    console.error('Bot error:', error);
});

// ==================== STARTUP MESSAGE ====================

console.log(`
🤖 Bot Panel Started Successfully!
👑 Owner: ${owner}
📱 Bot Name: ${nama}
🚀 Version: ${version}
⏰ Started at: ${new Date().toLocaleString('id-ID')}
`);

// Send startup notification to owner
try {
    const startupMsg = `
🚀 <b>Bot Panel Started Successfully!</b>

🤖 <b>Bot Name:</b> ${nama}
👑 <b>Owner:</b> ${settings.owner ? settings.owner : 'NOT SET!'}
📈 <b>Version:</b> ${version}
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
📊 <b>Users:</b> ${premiumUsers.length} premium, ${adminUsers.length} admin
🔄 <b>Bot Status:</b> ${botStatus}

${!settings.owner ? '❌ <b>WARNING: Owner not set in settings!</b>' : ''}

<i>Bot is now running and ready to serve!</i>
    `;
    
    // Hanya kirim jika owner ada
    if (settings.owner) {
        bot.sendMessage(settings.owner, startupMsg, { parse_mode: "HTML" })
            .catch(error => console.error('Failed to send startup message:', error));
    } else {
        console.error('❌ Cannot send startup message: owner not set in settings!');
    }
} catch (error) {
    console.error('Startup message error:', error);
}