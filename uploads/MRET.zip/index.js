const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const settings = require('./settings');
const axios = require('axios')
// Import config di atas file bot
const config = require('./settings.js'); // Sesuaikan path-nya
const tempUpdates = {};

// Konfigurasi Bot
const botToken = settings.token;
const owner = settings.owner;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumID.json';

// Inisialisasi Variabel
let premiumUsers = [];
let adminUsers = [];
let botStatus = 'running'; // running, stopped
let botStoppedBy = null;
let botStoppedTime = null;

// SIMPAN SESSION UNTUK TOMBOL
const activeSessions = new Map(); // key: message_id, value: user_id

// Baca file dengan error handling
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
    premiumUsers = [];
    fs.writeFileSync(premiumUsersFile, JSON.stringify([]));
}

try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
    adminUsers = [];
    fs.writeFileSync(adminfile, JSON.stringify([]));
}

// Inisialisasi Bot
const bot = new TelegramBot(botToken, { 
    polling: true,
    request: {
        timeout: 60000,
        agentOptions: {
            keepAlive: true,
            family: 4
        }
    }
});

// Bot Info
const nama = 'darz';
const author = 'darz';
const version = '3.0';

const startTime = Date.now();

// Utility Functions
const ALLOWED_GROUP_ID = -1002682347653; // ganti dengan ID grup lo

// Fungsi cek grup
function checkGroup(msg) {
    const chatId = msg.chat.id;

    if (chatId !== ALLOWED_GROUP_ID) {
        bot.sendMessage(chatId, `Gunakan di grup ress panel, sekali lagi melanggar gw kick no reff.\nGak ada akses? beli @kriszzyy`);
        return false;
    }
    return true;
}

function getRunDuration(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}

// Fungsi getPanelConfig
function getPanelConfig(version) {
    // Map version ke key di config
    const versionMap = {
        'v1': { domain: 'domain', key: 'plta' },
        'v2': { domain: 'domain2', key: 'plta2' },
        'v3': { domain: 'domain3', key: 'plta3' },
        'v4': { domain: 'domain4', key: 'plta4' } // Kalau ada v4
    };
    
    const mapping = versionMap[version];
    
    if (!mapping) {
        return { panelDomain: null, pltaKey: null };
    }
    
    // Ambil dari config berdasarkan mapping
    const panelDomain = config[mapping.domain];
    const pltaKey = config[mapping.key];
    
    // Cek apakah domain dan key valid (bukan '-')
    if (panelDomain === '-' || pltaKey === '-' || !panelDomain || !pltaKey) {
        return { panelDomain: null, pltaKey: null };
    }
    
    return {
        panelDomain: panelDomain,
        pltaKey: pltaKey
    };
}

function generatePassword(length = 6) {
    const chars = "1234567890";
    let pass = "";
    for (let i = 0; i < length; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pass;
}

// Helper Functions untuk Validasi - DIPERBAIKI
function isAdmin(userId) {
    if (!userId || !settings.owner) {
        console.log('isAdmin: Missing userId or owner');
        return false;
    }
    try {
        const userIdStr = userId.toString();
        const ownerStr = settings.owner.toString();
        
        return adminUsers.includes(userIdStr) || userIdStr === ownerStr;
    } catch (error) {
        console.error('Error in isAdmin:', error);
        return false;
    }
}

function isOwner(userId) {
    if (!userId || !settings.owner) return false;
    try {
        return userId.toString() === settings.owner.toString();
    } catch (error) {
        console.error('Error in isOwner:', error);
        return false;
    }
}

function isValidUser(userId) {
    if (!userId) return false;
    const userIdStr = userId.toString();
    return premiumUsers.includes(userIdStr) || isAdmin(userIdStr);
}

// Function untuk cek akses menu
function checkMenuAccess(userId, menuName) {
    if (!isAdmin(userId)) {
        return {
            allowed: false,
            message: `❌ <b>Menu ${menuName} hanya untuk admin!</b>\n\nSilakan hubungi admin untuk akses menu ini.`
        };
    }
    return { allowed: true };
}

// Panel Functions dengan error handling yang lebih baik
async function checkUser(domainX, apiKey, username) {
    try {
        console.log(`Checking user ${username} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/users?filter[username]=${username}`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            timeout: 30000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error checking user:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

async function createUser(domainX, apiKey, username, password, rootAdmin = false) {
    try {
        console.log(`Creating user ${username} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                email: `${username}@gmail.com`,
                username: username,
                first_name: username,
                last_name: "Member",
                language: "en",
                root_admin: rootAdmin,
                password: password,
            }),
            timeout: 30000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error creating user:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

async function createServerSimple(domainX, apiKey, userId, serverName, ram, disk, eggId, locId, image) {
    try {
        console.log(`Creating server for user ${userId} on ${domainX}`);
        const res = await fetch(`${domainX}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                name: serverName,
                description: `Server created by Bot Panel - ${new Date().toLocaleDateString('id-ID')}`,
                user: userId,
                egg: eggId,
                docker_image: image,
                startup: `if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}`,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start",
                    NODE_PACKAGES: "",
                    UNNODE_PACKAGES: ""
                },
                limits: {
                    memory: ram,
                    swap: 0,
                    disk: disk,
                    io: 500,
                    cpu: 0,
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 1,
                },
                deploy: {
                    locations: [parseInt(locId)],
                    dedicated_ip: false,
                    port_range: [],
                },
            }),
            timeout: 60000
        });
        
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        
        return await res.json();
    } catch (error) {
        console.error('Error creating server:', error);
        return { errors: [{ detail: `Connection error: ${error.message}` }] };
    }
}

function checkAccess(userId, chatType, commandName) {
    if (chatType === "private") {
        const userIdStr = userId.toString();
        
        if (settings.owner) {
            // Kirim peringatan ke semua admin
            adminUsers.forEach((admin) => {
                if (admin && admin.toString) {
                    try {
                        bot.sendMessage(
                            admin,
                            `🚨 <b>PERINGATAN AKSES PV!</b>\n👤 <a href="tg://user?id=${userId}">User ID: ${userId}</a> mencoba menggunakan command <b>/${commandName}</b> di Private Message!\n\n⚠️ Command panel hanya boleh digunakan di grup.`,
                            { parse_mode: "HTML" }
                        );
                    } catch (error) {
                        console.error('Failed to send warning to admin:', error);
                    }
                }
            });
            
            // Kirim ke owner jika belum termasuk di adminUsers
            const ownerStr = settings.owner.toString();
            if (ownerStr !== userIdStr) {
                try {
                    bot.sendMessage(
                        settings.owner,
                        `🚨 <b>PERINGATAN AKSES PV!</b>\n👤 <a href="tg://user?id=${userId}">User ID: ${userId}</a> mencoba menggunakan command <b>/${commandName}</b> di Private Message!\n\n⚠️ Command panel hanya boleh digunakan di grup.`,
                        { parse_mode: "HTML" }
                    );
                } catch (error) {
                    console.error('Failed to send warning to owner:', error);
                }
            }
        } else {
            console.error('Settings.owner is undefined!');
        }
        
        return false;
    }
    return true;
}

// Handle Panel Creation
async function handlePanelCreation(query, sessionOwner, messageId) {
    const data = query.data;
    console.log('\n========== HANDLE PANEL CREATION ==========');
    console.log('Data:', data);
    console.log('Session Owner:', sessionOwner);
    console.log('Message ID:', messageId);
    
    if (!data.startsWith("make_srv")) return;

    const parts = data.split("_");
    if (parts.length < 5) {
        console.log('❌ Invalid format, parts:', parts);
        return bot.answerCallbackQuery(query.id, { 
            text: "❌ Format callback data salah!", 
            show_alert: true 
        });
    }

    const srv = parts[1];
    const username = parts[2];
    const paket = parts[3];
    const password = parts.slice(4).join("_");
    const senderId = query.from.id.toString(); // PASTIKAN STRING

    console.log('Parsed data:', { srv, username, paket, password, senderId });
    console.log('Session owner match:', sessionOwner === senderId);

    // Validasi ulang session
    if (sessionOwner && sessionOwner !== senderId) {
        console.log('❌ Double check failed - not owner');
        await bot.answerCallbackQuery(query.id, {
            text: "❌ Akses Ditolak!\nIni bukan session kamu!",
            show_alert: true
        });
        return;
    }

    console.log('✅ Double check passed - processing panel creation');

    let domainX, apiKey;
    if (srv === "srv1") { 
        domainX = settings.domain; 
        apiKey = settings.plta; 
    } else if (srv === "srv2") { 
        domainX = settings.domain2; 
        apiKey = settings.plta2; 
    } else if (srv === "srv3") { 
        domainX = settings.domain3; 
        apiKey = settings.plta3; 
    }

    if (!domainX || !apiKey || domainX === '-' || apiKey === '-') {
        return bot.sendMessage(query.message.chat.id, 
            `❌ Konfigurasi ${srv.toUpperCase()} belum lengkap! Hubungi admin.`
        );
    }

    try {
        await bot.editMessageText(`⏳ Sedang membuat panel ${paket.toUpperCase()} untuk ${username}...`, {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id
        });

        const check = await checkUser(domainX, apiKey, username);
        
        if (check.errors) {
            console.error('User check error:', check.errors);
            return bot.editMessageText(
                `❌ Error cek user: ${check.errors[0]?.detail || 'Unknown error'}`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id
                }
            );
        }
        
        if (check.data && check.data.length > 0) {
            return bot.editMessageText(
                `❌ Username <b>${username}</b> sudah dipakai di ${srv.toUpperCase()}!`, 
                { 
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: "HTML" 
                }
            );
        }

        const rootAdmin = paket === "admin";
        const userRes = await createUser(domainX, apiKey, username, password, rootAdmin);
        
        if (userRes.errors) {
            console.error('User creation error:', userRes.errors);
            return bot.editMessageText(
                `❌ Error membuat user: ${userRes.errors[0]?.detail || 'Unknown error'}`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id
                }
            );
        }

        const user = userRes.attributes;

        if (!rootAdmin) {
            let ram = 0, disk = 0;
            if (paket !== "unli") {
                ram = parseInt(paket.replace("gb", "")) * 1024;
                disk = ram * 2;
            }
            
            const eggId = settings.eggs || 15;
            const locId = settings.loc || 1;
            const image = "ghcr.io/parkervcp/yolks:nodejs_20";

            const serverRes = await createServerSimple(domainX, apiKey, user.id, username, ram, disk, eggId, locId, image);
            
            if (serverRes.errors) {
                console.error('Server creation error:', serverRes.errors);
                // Tetap lanjut meski server gagal, karena user sudah dibuat
            }
        }

        const detailMsg = `
╔══════════════════════╗
║   ✅ PANEL BERHASIL DIBUAT ║
╚══════════════════════╝

📡 <b>SERVER:</b> ${srv.toUpperCase()}
👤 <b>USERNAME:</b> <code>${user.username}</code>
🔐 <b>PASSWORD:</b> <code>${password}</code>
📦 <b>PAKET:</b> ${paket.toUpperCase()}
🌐 <b>LOGIN:</b> <a href="${domainX}">${domainX}</a>
${rootAdmin ? "\n⚠️ <b>ROLE: ADMIN PANEL</b>" : ""}

━━━━━━━━━━━━━━━━━━━
<b>📌 RULES PANEL:</b>
• Dilarang DDOS / nyolong / ngintip panel lain
• Jangan buat panel kalau tidak dipakai
• Jangan jual terlalu murah
• Jangan sebarkan panel gratisan

❗ Melanggar aturan = kick + no reff!

━━━━━━━━━━━━━━━━━━━
<i>Powered by @kriszzyy</i>
        `;
        
        try {
    await bot.sendPhoto(query.from.id, pterodactyl, {
        caption: detailMsg,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { 
                        text: '🌐 Login Web Panel', 
                        url: `${domainX}/auth/login` 
                    }
                ],
                [
                    { 
                        text: "📋 Copy Password",
                        copy_text: {
                            text: password
                        }
                    }
                ]
            ]
        }
    });
    
    // Hapus session setelah berhasil kirim ke PV
    activeSessions.delete(messageId);
    
} catch (error) {
    // PERINGATAN JIKA BELUM START DI PV
    return bot.editMessageText(
        `⚠️ <b>Panel berhasil dibuat tetapi tidak bisa mengirim detail ke PV Anda!</b>\n\n` +
        `📝 <b>SOLUSI:</b>\n` +
        `1. Klik tombol dibawah untuk start bot di PV\n` +
        `2. Atau ketik <code>/start</code> di PV bot\n` +
        `3. Setelah itu coba buat panel lagi\n\n` +
        `🔗 <a href="https://t.me/${bot.options.username}">Start Bot di PV</a>`,
        { 
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: "🚀 START BOT DI PV", 
                            url: `https://t.me/${bot.options.username}?start=start` 
                        }
                    ],
                    [
                        { 
                            text: "🔄 COBA LAGI", 
                            callback_data: `make_${srv}_${username}_${paket}_${password}` 
                        }
                    ]
                ]
            }
        }
    );
}

        const ownerMsg = `
╔══════════════════════╗
║   📢 PANEL BARU DIBUAT   ║
╚══════════════════════╝

👤 <b>PEMBUAT:</b> <a href="tg://user?id=${query.from.id}">${query.from.first_name || 'Unknown'}</a>
🆔 <b>USER ID:</b> <code>${query.from.id}</code>
📋 <b>USERNAME:</b> <code>${username}</code>
📦 <b>PAKET:</b> ${paket.toUpperCase()}
📡 <b>SERVER:</b> ${srv.toUpperCase()}
🕐 <b>WAKTU:</b> ${new Date().toLocaleString('id-ID')}
        `;

        try {
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });

            // Kirim ke admin lain (kalo ada)
            if (adminUsers && adminUsers.length > 0) {
                adminUsers.forEach(async (adminId) => {
                    if (adminId !== settings.owner.toString()) {
                        try {
                            await bot.sendMessage(adminId, ownerMsg, { parse_mode: "HTML" });
                        } catch (error) {
                            console.error(`Failed to send notification to admin ${adminId}:`, error);
                        }
                    }
                });
            }
        } catch (error) {
            console.error('Failed to send notifications:', error);
        }

        await bot.editMessageText(
            `✅ Panel <b>${paket.toUpperCase()}</b> untuk username <b>${username}</b> berhasil dibuat di <b>${srv.toUpperCase()}</b>.\n\n📱 Detail login telah dikirim ke PV Anda.`, 
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: "HTML"
            }
        );

        await bot.answerCallbackQuery(query.id, { text: "✅ Panel berhasil dibuat!" });

    } catch (err) {
        console.error('Panel creation error:', err);
        
        let errorMsg = "⚠️ Gagal membuat panel.";
        if (err.message) {
            if (err.message.includes('ECONNREFUSED')) {
                errorMsg = "❌ Tidak dapat terhubung ke server panel.";
            } else if (err.message.includes('timeout')) {
                errorMsg = "⏰ Timeout saat membuat panel.";
            } else {
                errorMsg = `❌ Error: ${err.message}`;
            }
        }

        try {
            await bot.editMessageText(errorMsg, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id
            });

            await bot.answerCallbackQuery(query.id, { text: "❌ Gagal membuat panel!", show_alert: true });
        } catch (editError) {
            console.error('Error editing message:', editError);
        }
    }
}

// Middleware untuk block command saat bot stopped
bot.on("text", (msg) => {
    // Skip jika message dari bot atau bukan text command
    if (msg.from.is_bot || !msg.text) return;

    // Skip jika bot running
    if (botStatus === 'running') return;

    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;

    const isUserAdmin = isAdmin(userId);
    
    // Izinkan command control bot untuk admin
    const allowedCommands = ['/startbot', '/stopbot', '/restart', '/status'];
    const isControlCommand = allowedCommands.some(cmd => msg.text.startsWith(cmd));
    
    if (!isUserAdmin && !isControlCommand) {
        bot.sendMessage(chatId, 
            '🛑 <b>Bot sedang dalam status STOPPED</b>\n\n' +
            '🤖 Bot saat ini tidak merespon command.\n' +
            '📝 <b>Status:</b> 🔴 STOPPED\n\n' +
            'Silakan hubungi admin untuk memulai bot kembali.',
            { parse_mode: 'HTML' }
        );
        return; // Block command
    }
});

// ==================== BOT COMMANDS ====================

// START Command dengan tampilan lebih bagus
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;

    const caption = `
╔══════════════════════╗
║   🤖 BOT CREATE PANEL   ║
╚══════════════════════╝

✨ <b>Halo ${msg.from.first_name}!</b>

Saya adalah bot untuk membuat panel 
pterodactyl dengan mudah dan cepat.

━━━━━━━━━━━━━━━━━━━
📊 <b>INFORMASI BOT:</b>
• 👑 Owner: @darzBegginer
• 🔧 Version: ${version}
• 📅 Uptime: ${getRunDuration(startTime)}
• ⚡ Status: ${botStatus === 'running' ? '🟢 ONLINE' : '🔴 OFFLINE'}
━━━━━━━━━━━━━━━━━━━

Silakan pilih menu di bawah untuk memulai! 🚀
    `;

    const mainKeyboard = {
        inline_keyboard: [
            [
                { text: '⚡ CPANEL MENU', callback_data: 'cpanelmenu' },
                { text: '✨ FUN MENU', callback_data: 'funmenu' },
            ],
            [
                { text: '👑 OWNER MENU', callback_data: 'ownermenu' },
                { text: '💬 OWNER', url: 'https://t.me/darzBegginer' }
            ],
            [
                { text: '📢 CHANNEL', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }
            ]
        ]
    };

    bot.sendPhoto(chatId, thumbnail, {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: mainKeyboard
    });
});

// CEK SERVER Command dengan tampilan lebih bagus
bot.onText(/\/cekserver$/, async (msg) => {
    const chatId = msg.chat.id;
    
    const sentMessage = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Mengecek Server V1-V4...</b>\n\n</blockquote>`, { 
        parse_mode: 'HTML' 
    });

    (async () => {
        const servers = ['v1', 'v2', 'v3'];
        let serverStatuses = [];
        
        for (const version of servers) {
            const panelConfig = getPanelConfig(version);
            const serverName = `SERVER ${version.slice(1)}`;
            
            if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
                serverStatuses.push(`${serverName}  OFF ❌ (Konfigurasi hilang)`);
                continue;
            }

            try {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?per_page=1`, {
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` },
                    timeout: 5000
                });
                
                if (response.status === 200) {
                    serverStatuses.push(`${serverName}  ON ✅`);
                } else {
                    serverStatuses.push(`${serverName}  OFF ❌ (Status: ${response.status})`);
                }
                
            } catch (err) {
                console.error(`Error cek API server ${version}:`, err.message);
                
                let errorDetail = 'API Error';
                if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
                    errorDetail = 'Timeout';
                } else if (err.response && (err.response.status === 403 || err.response.status === 404)) {
                    errorDetail = 'Key/URL Salah';
                }
                
                serverStatuses.push(`${serverName}  OFF ❌ (${errorDetail})`);
            }
        }

        const message = `
╔══════════════════════╗
║   🤖 SERVER YANG ON   ║
╚══════════════════════╝
━━━━━━━━━━━━━━━━━━━
${serverStatuses.join('\n')}
━━━━━━━━━━━━━━━━━━━
        `;

        await bot.editMessageText(`<blockquote>${message}</blockquote>`, {
            chat_id: chatId,
            message_id: sentMessage.message_id,
            parse_mode: 'HTML'
        });
    })();
});

// TOTAL SERVER Command dengan tampilan lebih bagus
bot.onText(/\/totalserver$/, async (msg) => {
    const chatId = msg.chat.id;
    
    const sentMessage = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Menghitung total server di semua panel (V1-V3)...</b></blockquote>`, { 
        parse_mode: 'HTML' 
    });

    (async () => {
        const servers = ['v1', 'v2', 'v3'];
        let results = [];
        
        for (const version of servers) {
            const panelConfig = getPanelConfig(version);
            const serverName = `SERVER ${version.slice(1)}`;
            
            if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
                results.push(`${serverName} ❌ Konfigurasi tidak ditemukan`);
                continue;
            }

            try {
                let currentServerCount = 0;
                let page = 1;
                let hasMore = true;

                while (hasMore) {
                    const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
                        headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` },
                        timeout: 10000
                    });

                    const result = response.data;
                    currentServerCount += result.data.length;
                    hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                    page++;
                }

                results.push(`${serverName} ✅\n   🌐 ${panelConfig.panelDomain}\n   📊 Total: <code>${currentServerCount} Server</code>`);
                
            } catch (err) {
                console.error(`Error total server ${version}:`, err.message);
                
                let errorDetail = '❌ Gagal mengambil data';
                if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
                    errorDetail = '❌ Timeout';
                } else if (err.response && (err.response.status === 403 || err.response.status === 404)) {
                    errorDetail = '❌ Key/URL Salah';
                }
                
                results.push(`${serverName} ${errorDetail}\n   🌐 ${panelConfig.panelDomain}`);
            }
        }

        const message = `
╔══════════════════════╗
║   📊 TOTAL SERVER   ║
╚══════════════════════╝
━━━━━━━━━━━━━━━━━━━━━
${results.join('\n\n')}
━━━━━━━━━━━━━━━━━━━━━
        `;

        await bot.editMessageText(`<blockquote>${message}</blockquote>`, {
            chat_id: chatId,
            message_id: sentMessage.message_id,
            parse_mode: 'HTML'
        });
    })();
});

// DONE Command dengan tampilan lebih bagus
bot.onText(/\/done$/, (msg) => {
    const chatId = msg.chat.id;
    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan:</b> 
<code>/done NamaProduk,Harga,Status</code>

📌 <b>Contoh:</b>
<code>/done Panel 1GB,50000,LUNAS</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/done (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1].split(",");

    if (input.length < 3) {
        const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan:</b> 
<code>/done NamaProduk,Harga,Status</code>

📌 <b>Contoh:</b>
<code>/done Panel 1GB,50000,LUNAS</code>
        `;
        return bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
    }

    const produk = input[0].trim();
    const harga = input[1].trim();
    const status = input[2].trim();

    const tanggal = new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    const struk = `
╔══════════════════════╗
║   ✅ TRANSAKSI DONE   ║
╚══════════════════════╝

Terima kasih sudah melakukan pembayaran 💙

━━━━━━━━━━━━━━━━━━━
📦 <b>Produk:</b> ${produk}
💰 <b>Harga:</b> Rp ${harga}
💳 <b>Status:</b> ${status} ✅
📅 <b>Tanggal:</b> ${tanggal}
━━━━━━━━━━━━━━━━━━━

🚀 <b>Contact:</b>
• WhatsApp: 088221845865
• Telegram: @darzBegginer

✨ <b>Testimoni:</b>
• Telegram: @TestiDarz
• WhatsApp: https://whatsapp.com/channel/0029VakpH6q3QxS1DXW5HD3z

━━━━━━━━━━━━━━━━━━━
🚀 Selamat menggunakan layanan kami
✨ Semoga anda senang dengan produk/jasa dari kami
    `;

    bot.sendMessage(chatId, struk, { parse_mode: "HTML" });
});

// CEK ID Command dengan tampilan lebih bagus
bot.onText(/\/cekid$/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username || msg.from.first_name;
    const id = msg.from.id;
    
    const text12 = `
╔══════════════════════╗
║   🔍 CEK ID TELEGRAM   ║
╚══════════════════════╝

👤 <b>Username:</b> @${sender}
🆔 <b>User ID:</b> <code>${id}</code>
💬 <b>Chat ID:</b> <code>${chatId}</code>
    `;
    
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '📢 Channel Info', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }, 
                    { text: '👑 Owner', url: 'https://t.me/darzBegginer' }
                ]
            ]
        }
    };
    
    bot.sendMessage(chatId, text12, { 
        parse_mode: 'HTML', 
        reply_markup: keyboard 
    });
});

// ==================== DI BAGIAN COMMAND ====================
    
// PREMIUM PANEL Commands dengan format helper
const paketList = ["1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","9gb","10gb","unli"];

// Handler untuk command tanpa parameter
paketList.forEach((paket) => {
    bot.onText(new RegExp(`\\/${paket}$`), (msg) => {
        const chatId = msg.chat.id;
        const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan:</b> <code>/${paket} username</code>

📌 <b>Contoh:</b>
<code>/${paket} joko123</code>
        `;
        
        bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
    });
});

// ==================== PERBAIKAN HANDLER COMMAND ====================

// Handler untuk command dengan parameter
paketList.forEach((paket) => {
    bot.onText(new RegExp(`\\/${paket} (.+)`), async (msg, match) => {
        if (!checkGroup(msg)) return;
        
        const chatId = msg.chat.id;
        const chatType = msg.chat.type;
        const username = match[1].trim();
        const userId = msg.from.id; // 👈 INI NUMBER

        // Validasi username
        if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
            return bot.sendMessage(chatId, 
                '╔══════════════════════╗\n' +
                '║   ❌ USERNAME TIDAK VALID   ║\n' +
                '╚══════════════════════╝\n\n' +
                '📝 Username hanya boleh huruf, angka, dan underscore\n' +
                '📏 Minimal 3 karakter', {
                parse_mode: "HTML"
            });
        }

        if (!checkAccess(userId, chatType, paket)) {
            return bot.sendMessage(chatId, 
                '╔══════════════════════╗\n' +
                '║   ❌ AKSES DITOLAK   ║\n' +
                '╚══════════════════════╝\n\n' +
                `⚠️ Command <b>/${paket}</b> hanya dapat digunakan di grup, bukan di Private Message.\n\n` +
                `📢 Silakan gunakan command ini di grup yang diizinkan.`, {
                parse_mode: "HTML"
            });
        }

        // Cek status server dulu
        const statusMsg = await bot.sendMessage(chatId, `<blockquote>⏳ <b>Mengecek status server...</b></blockquote>`, {
            parse_mode: 'HTML'
        });

        const servers = ['v1', 'v2', 'v3'];
        let statusEmoji = {};
        
        for (const version of servers) {
            const panelConfig = getPanelConfig(version);
            
            if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
                statusEmoji[version] = '❌';
                continue;
            }

            try {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?per_page=1`, {
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` },
                    timeout: 5000
                });
                
                if (response.status === 200) {
                    statusEmoji[version] = '✅';
                } else {
                    statusEmoji[version] = '❌';
                }
                
            } catch (err) {
                statusEmoji[version] = '❌';
            }
        }

        // Hapus pesan status
        await bot.deleteMessage(chatId, statusMsg.message_id);

        const password = username + generatePassword(6);

        // Buat keyboard dengan status server
        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: `🚀 SERVER 1 ${statusEmoji['v1']}`, 
                        callback_data: `make_srv1_${username}_${paket}_${password}` 
                    }
                ],
                [
                    { 
                        text: `🚀 SERVER 2 ${statusEmoji['v2']}`, 
                        callback_data: `make_srv2_${username}_${paket}_${password}` 
                    }
                ],
                [
                    { 
                        text: `🚀 SERVER 3 ${statusEmoji['v3']}`, 
                        callback_data: `make_srv3_${username}_${paket}_${password}` 
                    }
                ],
            ],
        };

        // Kirim pesan dengan keyboard
        let statusInfo = `
╔══════════════════════╗
║   📊 STATUS SERVER   ║
╚══════════════════════╝
SERVER 1: ${statusEmoji['v1']}
SERVER 2: ${statusEmoji['v2']}
SERVER 3: ${statusEmoji['v3']}
        `;

        const sentMsg = await bot.sendMessage(chatId, 
            `${statusInfo}\n━━━━━━━━━━━━━━━━━━━\n📋 Pilih server untuk membuat <b>${username}</b> [${paket.toUpperCase()}]`, {
            parse_mode: "HTML",
            reply_markup: keyboard,
        });
        
        // 🔥 PERBAIKAN: Simpan userId sebagai STRING
        
// Simpan session sebagai STRING
activeSessions.set(sentMsg.message_id, userId.toString());
console.log('📝 Session saved:', {
    messageId: sentMsg.message_id,
    userId: userId.toString(),
    allSessions: Array.from(activeSessions.entries())
});
        
        // Auto hapus session setelah 5 menit
        setTimeout(() => {
            activeSessions.delete(sentMsg.message_id);
        }, 5 * 60 * 1000);
    });
});

// ADMIN PANEL Command dengan format helper
bot.onText(/\/cadp$/, (msg) => {
    const chatId = msg.chat.id;
    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan:</b> <code>/cadp username</code>

📌 <b>Contoh:</b>
<code>/cadp admin123</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/cadp (.+)/, async (msg, match) => {
    if (!checkGroup(msg)) return;
    
    const chatId = msg.chat.id;
    const chatType = msg.chat.type;
    const username = match[1].trim();
    const userId = msg.from.id;

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ AKSES DITOLAK   ║\n' +
            '╚══════════════════════╝\n\n' +
            'Command ini hanya untuk admin!', {
            parse_mode: "HTML"
        });
    }
    
    // Validasi username
    if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ USERNAME TIDAK VALID   ║\n' +
            '╚══════════════════════╝\n\n' +
            '📝 Username hanya boleh huruf, angka, dan underscore\n' +
            '📏 Minimal 3 karakter', {
            parse_mode: "HTML"
        });
    }

    const password = generatePassword(8);

    const keyboard = {
        inline_keyboard: [
            [
                { text: "🚀 SERVER 1", callback_data: `make_srv1_${username}_admin_${password}` },
                { text: "🚀 SERVER 2", callback_data: `make_srv2_${username}_admin_${password}` },
                { text: "🚀 SERVER 3", callback_data: `make_srv3_${username}_admin_${password}` },
            ],
        ],
    };

    bot.sendMessage(chatId, `📋 Pilih server untuk membuat Admin Panel <b>${username}</b>`, {
        parse_mode: "HTML",
        reply_markup: keyboard,
    });
});

// ==================== CALLBACK QUERY HANDLER (SATU UNTUK SEMUA) ====================


// ==================== PERBAIKAN CALLBACK HANDLER ====================

// ==================== CALLBACK QUERY HANDLER DEBUG ====================

bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const msgId = query.message.message_id;
    const data = query.data;
    const userId = query.from.id.toString();
    const userFirstName = query.from.first_name || 'Unknown';

    try {
        console.log('\n========== CALLBACK RECEIVED ==========');
        console.log('User:', userFirstName, 'ID:', userId);
        console.log('Message ID:', msgId);
        console.log('Data:', data);
        
        // CEK SESSION
        const sessionOwner = activeSessions.get(msgId);
        console.log('Session Owner:', sessionOwner);
        console.log('Session Owner Type:', typeof sessionOwner);
        console.log('User ID Type:', typeof userId);
        console.log('Match:', sessionOwner === userId);
        console.log('Session Map:', Array.from(activeSessions.entries()));

        // KALAU TOMBOL MAKE_SRV
        if (data.startsWith("make_srv")) {
            // KALAU ADA SESSION OWNER
            if (sessionOwner) {
                console.log('Session exists, checking ownership...');
                
                // KALAU BUKAN PEMILIK
                if (sessionOwner !== userId) {
                    console.log('❌ ACCESS DENIED - Not owner');
                    await bot.answerCallbackQuery(query.id, {
                        text: "❌ Access Denied\nTombol ini hanya untuk yang memulai perintah!",
                        show_alert: true
                    });
                    return;
                }
                
                // KALAU PEMILIK
                console.log('✅ ACCESS GRANTED - Owner');
                await bot.answerCallbackQuery(query.id, { text: "⏳ Memproses..." });
                return handlePanelCreation(query, sessionOwner, msgId);
            } 
            // KALAU TIDAK ADA SESSION (MUNGKIN SUDAH EXPIRED)
            else {
                console.log('⚠️ No session found for this message');
                await bot.answerCallbackQuery(query.id, {
                    text: "❌ Session expired!\nSilakan ulangi perintah.",
                    show_alert: true
                });
                return;
            }
        }

        // ================ HANDLE UPDATE PLTA/PLTC/DOMAIN ================
        if (data.startsWith("up_plta") || data.startsWith("up_pltc") || data.startsWith("up_domain")) {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya admin yang bisa update settings!",
                    show_alert: true
                });
            }

            const parts = data.split("_");
            const type = parts[1]; // plta, pltc, domain
            const srv = parts[2]; // srv1, srv2, srv3
            const newValue = parts.slice(3).join("_"); // nilai baru

            let key;
            if (type === 'plta') {
                key = srv === "srv1" ? "plta" : srv === "srv2" ? "plta2" : "plta3";
            } else if (type === 'pltc') {
                key = srv === "srv1" ? "pltc" : srv === "srv2" ? "pltc2" : "pltc3";
            } else if (type === 'domain') {
                key = srv === "srv1" ? "domain" : srv === "srv2" ? "domain2" : "domain3";
            }

            if (!key) return bot.answerCallbackQuery(query.id, { text: "❌ Server tidak valid!" });

            // update settings.js secara dinamis
            settings[key] = newValue;
            fs.writeFileSync('./settings.js', `module.exports = ${JSON.stringify(settings, null, 2)}`);

            bot.editMessageText(`✅ Berhasil update <b>${type.toUpperCase()}</b> di ${srv.toUpperCase()} → <code>${newValue}</code>`, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: "HTML"
            });

            return bot.answerCallbackQuery(query.id, { text: "✅ Berhasil diupdate!" });
        }

        // ================ HANDLE MENU NAVIGATION ================
        if (data === "cpanelmenu") {
            const caption = `
╔══════════════════════╗
║   ⚡ CPANEL MENU   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
📦 <b>CREATE PANEL:</b>
• /1gb [nama]
• /2gb [nama]
• /3gb [nama]
• /4gb [nama]
• /5gb [nama]
• /6gb [nama]
• /7gb [nama]
• /8gb [nama]
• /9gb [nama]
• /10gb [nama]
• /unli [nama]
• /cadp [nama] (admin)
━━━━━━━━━━━━━━━━━━━

⚠️ <b>PERINGATAN:</b>
• Jangan buat panel di PV
• Gunakan di grup yang tersedia
• Melanggar = kick + no reff!
━━━━━━━━━━━━━━━━━━━

「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "funmenu") {
            const caption = `
╔══════════════════════╗
║   ✨ FUN MENU   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
🎮 <b>COMMANDS:</b>
• /done [Nama],[Harga],[Status]
• /cekid
━━━━━━━━━━━━━━━━━━━

「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "ownermenu") {
            // PERBAIKAN: Gunakan fungsi validasi yang konsisten
            const accessCheck = checkMenuAccess(userId, "Owner");
            if (!accessCheck.allowed) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Menu hanya untuk admin!",
                    show_alert: true
                });
            }

            const caption = `
╔══════════════════════╗
║   👑 OWNER MENU   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
🤖 <b>BOT CONTROL:</b>
• /startbot
• /stopbot
• /restart
• /status

🛠 <b>USER MANAGEMENT:</b>
• /addowner [id]
• /addprem [id]
• /delowner [id]
• /delprem [id]
• /listusr

🔧 <b>SETTINGS:</b>
• /upplta [key]
• /uppltc [key]
• /updomain [url]
━━━━━━━━━━━━━━━━━━━

「 ⿻ Powered by @darzBegginer 」
`;
            return bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back" }]] }
            });
        }

        if (data === "back") {
            const mainCaption = `
╔══════════════════════╗
║   🤖 BOT CREATE PANEL   ║
╚══════════════════════╝

✨ <b>Halo ${query.from.first_name}!</b>

Saya adalah bot untuk membuat panel 
pterodactyl dengan mudah dan cepat.

━━━━━━━━━━━━━━━━━━━
📊 <b>INFORMASI BOT:</b>
• 👑 Owner: @darzBegginer
• 🔧 Version: ${version}
• 📅 Uptime: ${getRunDuration(startTime)}
• ⚡ Status: ${botStatus === 'running' ? '🟢 ONLINE' : '🔴 OFFLINE'}
━━━━━━━━━━━━━━━━━━━

Silakan pilih menu di bawah untuk memulai! 🚀
`;

            const mainKeyboard = {
                inline_keyboard: [
                    [
                        { text: '⚡ CPANEL MENU', callback_data: 'cpanelmenu' },
                        { text: '✨ FUN MENU', callback_data: 'funmenu' },
                    ],
                    [
                        { text: '👑 OWNER MENU', callback_data: 'ownermenu' },
                        { text: '💬 OWNER', url: 'https://t.me/darzBegginer' }
                    ],
                    [
                        { text: '📢 CHANNEL', url: 'https://whatsapp.com/channel/0029Vag8DKREawdziBjlf02o' }
                    ]
                ]
            };

            return bot.editMessageCaption(mainCaption, {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "HTML",
                reply_markup: mainKeyboard
            });
        }

        // ================ BOT CONTROL HANDLERS ================
        if (data === "restart_bot") {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya owner dan admin yang bisa restart bot!",
                    show_alert: true
                });
            }

            await bot.answerCallbackQuery(query.id, { text: "🔄 Restarting bot..." });
            
            // Simulasikan command restart
            const fakeMsg = {
                chat: { id: query.message.chat.id, type: query.message.chat.type, title: query.message.chat.title },
                from: query.from,
                text: '/restart'
            };
            
            // Panggil handler restart
            bot.emit('text', fakeMsg);
            return;
        }

        if (data === "debug_settings") {
            if (!isAdmin(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya owner dan admin yang bisa akses!",
                    show_alert: true
                });
            }

            const debugInfo = `
╔══════════════════════╗
║   🔧 DEBUG SETTINGS   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
<b>SERVER 1:</b>
🌐 Domain: ${settings.domain || 'Not set'}
🔑 PLTA: ${settings.plta ? settings.plta.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc ? settings.pltc.substring(0, 15) + '...' : 'Not set'}

<b>SERVER 2:</b>
🌐 Domain: ${settings.domain2 || 'Not set'}
🔑 PLTA: ${settings.plta2 ? settings.plta2.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc2 ? settings.pltc2.substring(0, 15) + '...' : 'Not set'}

<b>SERVER 3:</b>
🌐 Domain: ${settings.domain3 || 'Not set'}
🔑 PLTA: ${settings.plta3 ? settings.plta3.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc3 ? settings.pltc3.substring(0, 15) + '...' : 'Not set'}

━━━━━━━━━━━━━━━━━━━
👑 Owner: ${settings.owner}
👥 Admins: ${adminUsers.length}
⭐ Premium: ${premiumUsers.length}
📊 Temp Updates: ${Object.keys(tempUpdates).length}
━━━━━━━━━━━━━━━━━━━
            `;

            return bot.editMessageText(debugInfo, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "🔄 Restart Bot", callback_data: "restart_bot" },
                            { text: "⬅️ Back to Status", callback_data: "back_to_status" }
                        ]
                    ]
                }
            });
        }

        if (data === "back_to_status") {
            // Panggil command status
            const fakeMsg = {
                chat: { id: query.message.chat.id, type: query.message.chat.type, title: query.message.chat.title },
                from: query.from,
                text: '/status'
            };
            bot.emit('text', fakeMsg);
            return;
        }

        // If no handler found
        console.log('No handler for callback:', data);
        bot.answerCallbackQuery(query.id, { text: "⚠️ Opsi tidak dikenali!", show_alert: true });

        } catch (error) {
        console.error('Callback error:', error);
        await bot.answerCallbackQuery(query.id, { 
            text: "❌ Terjadi kesalahan!", 
            show_alert: true 
        });
    }
});

// ==================== OWNER COMMANDS DENGAN BALAS PESAN ====================

// ADDOWNER Command dengan format helper dan balas pesan
bot.onText(/\/addowner$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan salah satu:</b>
<code>/addowner user_id</code>
ATAU
Balas pesan user dengan <code>/addowner</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ USER ID TIDAK VALID   ║\n' +
            '╚══════════════════════╝\n\n' +
            '📝 User ID hanya boleh angka!', {
            parse_mode: "HTML"
        });
    }

    // Cek jika user sudah menjadi admin
    if (adminUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ❌ USER SUDAH ADMIN   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `📊 Status: Sudah admin`, {
            parse_mode: "HTML"
        });
    }

    // Tambahkan ke admin
    adminUsers.push(targetId);
    fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

    bot.sendMessage(chatId, 
        `╔══════════════════════╗\n` +
        `║   ✅ ADMIN DITAMBAHKAN   ║\n` +
        `╚══════════════════════╝\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `👑 Role: Admin Panel\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`, {
        parse_mode: "HTML"
    });

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `👑 <b>ADMIN BARU DITAMBAHKAN</b>\n\n` +
            `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk addowner dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/addowner') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user sudah menjadi admin
        if (adminUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `╔══════════════════════╗\n` +
                `║   ❌ USER SUDAH ADMIN   ║\n` +
                `╚══════════════════════╝\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `📊 Status: Sudah admin`, {
                parse_mode: "HTML"
            });
        }

        // Tambahkan ke admin
        adminUsers.push(targetId);
        fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

        bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ✅ ADMIN DITAMBAHKAN   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `👑 Role: Admin Panel\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`, {
            parse_mode: "HTML"
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `👑 <b>ADMIN BARU DITAMBAHKAN</b>\n\n` +
                `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }

        // Coba kirim notifikasi ke user yang ditambahkan
        try {
            bot.sendMessage(targetId,
                `🎉 <b>SELAMAT!</b>\n\n` +
                `Anda telah ditambahkan sebagai <b>Admin Panel</b>!\n\n` +
                `👑 <b>Hak Akses:</b>\n` +
                `• Buat panel admin\n` +
                `• Manage user premium\n` +
                `• Control bot (start/stop/restart)\n` +
                `• Update settings panel\n\n` +
                `⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                `⚠️ <b>Note:</b> Gunakan akses dengan bijak!`,
                { parse_mode: "HTML" }
            );
        } catch (error) {
            console.error('Failed to send notification to new admin:', error);
        }
    }
});

// ADDPREM Command dengan format helper dan balas pesan
bot.onText(/\/addprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan salah satu:</b>
<code>/addprem user_id</code>
ATAU
Balas pesan user dengan <code>/addprem</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ USER ID TIDAK VALID   ║\n' +
            '╚══════════════════════╝\n\n' +
            '📝 User ID hanya boleh angka!', {
            parse_mode: "HTML"
        });
    }

    // Cek jika user sudah premium
    if (premiumUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ❌ USER SUDAH PREMIUM   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `⭐ Status: Sudah premium`, {
            parse_mode: "HTML"
        });
    }

    // Tambahkan ke premium
    premiumUsers.push(targetId);
    fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

    bot.sendMessage(chatId, 
        `╔══════════════════════╗\n` +
        `║   ⭐ PREMIUM DITAMBAHKAN   ║\n` +
        `╚══════════════════════╝\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `🎯 Role: Premium User\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
        `✨ <b>Fitur yang didapat:</b>\n` +
        `• Akses semua command panel\n` +
        `• Priority support`, {
        parse_mode: "HTML"
    });

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `⭐ <b>PREMIUM USER BARU</b>\n\n` +
            `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk addprem dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/addprem') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user sudah premium
        if (premiumUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `╔══════════════════════╗\n` +
                `║   ❌ USER SUDAH PREMIUM   ║\n` +
                `╚══════════════════════╝\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⭐ Status: Sudah premium`, {
                parse_mode: "HTML"
            });
        }

        // Tambahkan ke premium
        premiumUsers.push(targetId);
        fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

        bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ⭐ PREMIUM DITAMBAHKAN   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `🎯 Role: Premium User\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
            `✨ <b>Fitur yang didapat:</b>\n` +
            `• Akses semua command panel\n` +
            `• Priority support`, {
            parse_mode: "HTML"
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `⭐ <b>PREMIUM USER BARU</b>\n\n` +
                `👤 Added by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }

        // Coba kirim notifikasi ke user yang ditambahkan
        try {
            bot.sendMessage(targetId,
                `🎉 <b>SELAMAT!</b>\n\n` +
                `Anda telah diupgrade menjadi <b>Premium User</b>!\n\n` +
                `⭐ <b>Fitur Premium:</b>\n` +
                `• Akses semua command panel (1GB - UNLI)\n` +
                `• Priority support\n` +
                `• Akses penuh ke semua server\n\n` +
                `⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                `Terima kasih telah menggunakan layanan kami! 🚀`,
                { parse_mode: "HTML" }
            );
        } catch (error) {
            console.error('Failed to send notification to new premium user:', error);
        }
    }
});

// DELOWNER Command dengan format helper dan balas pesan
bot.onText(/\/delowner$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan salah satu:</b>
<code>/delowner user_id</code>
ATAU
Balas pesan user dengan <code>/delowner</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ USER ID TIDAK VALID   ║\n' +
            '╚══════════════════════╝\n\n' +
            '📝 User ID hanya boleh angka!', {
            parse_mode: "HTML"
        });
    }

    // Cek jika target adalah owner utama
    if (targetId === settings.owner.toString()) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ TIDAK BISA HAPUS OWNER   ║\n' +
            '╚══════════════════════╝\n\n' +
            '👑 Owner utama tidak dapat dihapus dari sistem.', {
            parse_mode: "HTML"
        });
    }

    // Cek jika user adalah admin
    if (!adminUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ❌ USER BUKAN ADMIN   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `📊 Status: Bukan admin`, {
            parse_mode: "HTML"
        });
    }

    // Hapus dari admin
    adminUsers = adminUsers.filter(id => id !== targetId);
    fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

    bot.sendMessage(chatId, 
        `╔══════════════════════╗\n` +
        `║   🗑️ ADMIN DIHAPUS   ║\n` +
        `╚══════════════════════╝\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `👑 Role: User Biasa\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`, {
        parse_mode: "HTML"
    });

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `🗑️ <b>ADMIN DIHAPUS</b>\n\n` +
            `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk delowner dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/delowner') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika target adalah owner utama
        if (targetId === settings.owner.toString()) {
            return bot.sendMessage(chatId, 
                '╔══════════════════════╗\n' +
                '║   ❌ TIDAK BISA HAPUS OWNER   ║\n' +
                '╚══════════════════════╝\n\n' +
                '👑 Owner utama tidak dapat dihapus dari sistem.', {
                parse_mode: "HTML"
            });
        }

        // Cek jika user adalah admin
        if (!adminUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `╔══════════════════════╗\n` +
                `║   ❌ USER BUKAN ADMIN   ║\n` +
                `╚══════════════════════╝\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `📊 Status: Bukan admin`, {
                parse_mode: "HTML"
            });
        }

        // Hapus dari admin
        adminUsers = adminUsers.filter(id => id !== targetId);
        fs.writeFileSync(adminfile, JSON.stringify(adminUsers));

        bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   🗑️ ADMIN DIHAPUS   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `👑 Role: User Biasa\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`, {
            parse_mode: "HTML"
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `🗑️ <b>ADMIN DIHAPUS</b>\n\n` +
                `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }
    }
});

// DELPREM Command dengan format helper dan balas pesan
bot.onText(/\/delprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const formatMessage = `
╔══════════════════════╗
║   ❌ FORMAT SALAH   ║
╚══════════════════════╝

📝 <b>Gunakan salah satu:</b>
<code>/delprem user_id</code>
ATAU
Balas pesan user dengan <code>/delprem</code>
    `;
    
    bot.sendMessage(chatId, formatMessage, { parse_mode: "HTML" });
});

bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const targetId = match[1].trim();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    // Validasi user ID
    if (!/^\d+$/.test(targetId)) {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ USER ID TIDAK VALID   ║\n' +
            '╚══════════════════════╝\n\n' +
            '📝 User ID hanya boleh angka!', {
            parse_mode: "HTML"
        });
    }

    // Cek jika user adalah premium
    if (!premiumUsers.includes(targetId)) {
        return bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   ❌ USER BUKAN PREMIUM   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User ID: <code>${targetId}</code>\n` +
            `⭐ Status: Bukan premium`, {
            parse_mode: "HTML"
        });
    }

    // Hapus dari premium
    premiumUsers = premiumUsers.filter(id => id !== targetId);
    fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

    bot.sendMessage(chatId, 
        `╔══════════════════════╗\n` +
        `║   📉 PREMIUM DIHAPUS   ║\n` +
        `╚══════════════════════╝\n\n` +
        `👤 User ID: <code>${targetId}</code>\n` +
        `🎯 Role: User Biasa\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
        `⚠️ <b>User kehilangan akses:</b>\n` +
        `• Fitur premium panel\n` +
        `• Priority support`, {
        parse_mode: "HTML"
    });

    // Kirim notifikasi ke owner
    if (settings.owner && userId !== settings.owner.toString()) {
        bot.sendMessage(settings.owner,
            `📉 <b>PREMIUM USER DIHAPUS</b>\n\n` +
            `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
            { parse_mode: "HTML" }
        );
    }
});

// Handler untuk delprem dengan balas pesan
bot.on("message", (msg) => {
    if (msg.reply_to_message && msg.text === '/delprem') {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();
        const repliedUser = msg.reply_to_message.from;
        const targetId = repliedUser.id.toString();

        if (!isAdmin(userId)) {
            return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
        }

        // Cek jika user adalah premium
        if (!premiumUsers.includes(targetId)) {
            return bot.sendMessage(chatId, 
                `╔══════════════════════╗\n` +
                `║   ❌ USER BUKAN PREMIUM   ║\n` +
                `╚══════════════════════╝\n\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⭐ Status: Bukan premium`, {
                parse_mode: "HTML"
            });
        }

        // Hapus dari premium
        premiumUsers = premiumUsers.filter(id => id !== targetId);
        fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));

        bot.sendMessage(chatId, 
            `╔══════════════════════╗\n` +
            `║   📉 PREMIUM DIHAPUS   ║\n` +
            `╚══════════════════════╝\n\n` +
            `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
            `🆔 User ID: <code>${targetId}</code>\n` +
            `🎯 Role: User Biasa\n` +
            `⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
            `⚠️ <b>User kehilangan akses:</b>\n` +
            `• Fitur premium panel\n` +
            `• Priority support`, {
            parse_mode: "HTML"
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            bot.sendMessage(settings.owner,
                `📉 <b>PREMIUM USER DIHAPUS</b>\n\n` +
                `👤 Removed by: <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>\n` +
                `👤 User: <a href="tg://user?id=${targetId}">${repliedUser.first_name || 'Unknown'}</a>\n` +
                `🆔 User ID: <code>${targetId}</code>\n` +
                `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "HTML" }
            );
        }
    }
});

// LISTUSR Command
bot.onText(/\/listusr/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    let adminList = "";
    adminUsers.forEach((id, i) => {
        adminList += `${i + 1}. <code>${id}</code>\n`;
    });

    let premiumList = "";
    premiumUsers.forEach((id, i) => {
        premiumList += `${i + 1}. <code>${id}</code>\n`;
    });

    const message = `
╔══════════════════════╗
║   📋 DAFTAR USER   ║
╚══════════════════════╝

👑 <b>ADMIN (${adminUsers.length}):</b>
${adminList || '• Tidak ada admin'}

⭐ <b>PREMIUM (${premiumUsers.length}):</b>
${premiumList || '• Tidak ada premium'}

━━━━━━━━━━━━━━━━━━━
📊 <b>Total:</b> ${adminUsers.length} Admin, ${premiumUsers.length} Premium
    `;

    bot.sendMessage(chatId, message, { parse_mode: "HTML" });
});

// UPDATE SETTINGS Commands
// === Command Update PLTA ===
bot.onText(/\/upplta (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);

    // validasi admin
    if (userId !== String(owner) && !adminUsers.includes(userId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner/Admin!");
    }

    const newPlta = match[1].trim();

    const keyboard = {
        inline_keyboard: [
            [
                { text: "⚡ SERVER 1", callback_data: `up_plta_srv1_${newPlta}` },
                { text: "⚡ SERVER 2", callback_data: `up_plta_srv2_${newPlta}` },
                { text: "⚡ SERVER 3", callback_data: `up_plta_srv3_${newPlta}` },
            ]
        ]
    };

    bot.sendMessage(chatId, `📋 Mau update <b>PLTA</b> menjadi <code>${newPlta.substring(0, 15)}...</code> di server mana?`, {
        parse_mode: "HTML",
        reply_markup: keyboard
    });
});

// DEBUG SETTINGS Command
bot.onText(/\/debugsettings$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk admin!');
    }

    const debugInfo = `
╔══════════════════════╗
║   🔧 DEBUG SETTINGS   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
<b>SERVER 1:</b>
🌐 Domain: ${settings.domain || 'Not set'}
🔑 PLTA: ${settings.plta ? settings.plta.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc ? settings.pltc.substring(0, 15) + '...' : 'Not set'}

<b>SERVER 2:</b>
🌐 Domain: ${settings.domain2 || 'Not set'}
🔑 PLTA: ${settings.plta2 ? settings.plta2.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc2 ? settings.pltc2.substring(0, 15) + '...' : 'Not set'}

<b>SERVER 3:</b>
🌐 Domain: ${settings.domain3 || 'Not set'}
🔑 PLTA: ${settings.plta3 ? settings.plta3.substring(0, 15) + '...' : 'Not set'}
🔑 PLTC: ${settings.pltc3 ? settings.pltc3.substring(0, 15) + '...' : 'Not set'}

━━━━━━━━━━━━━━━━━━━
👑 Owner: ${owner}
👥 Admins: ${adminUsers.length}
⭐ Premium: ${premiumUsers.length}
📊 Temp Updates: ${Object.keys(tempUpdates).length}
━━━━━━━━━━━━━━━━━━━
    `;

    bot.sendMessage(chatId, debugInfo, { parse_mode: 'HTML' });
});

// STATUS Command
bot.onText(/\/status$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!settings.owner) {
        return bot.sendMessage(chatId, 
            '❌ <b>Error: Owner not configured!</b>\n\nSilakan cek file settings.js.',
            { parse_mode: 'HTML' }
        );
    }

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    const memoryUsage = process.memoryUsage();
    const statusMessage = `
╔══════════════════════╗
║   🤖 BOT STATUS   ║
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━━
📊 <b>SYSTEM INFO:</b>
├─ 🕒 Uptime: ${getRunDuration(startTime)}
├─ 📈 Memory: ${(memoryUsage.rss / 1024 / 1024).toFixed(2)} MB
├─ 🔄 Node.js: ${process.version}
└─ 📁 Platform: ${process.platform}

👥 <b>USER STATISTICS:</b>
├─ 👑 Owner: <code>${settings.owner}</code>
├─ 🔧 Admins: ${adminUsers.length} users
└─ ⭐ Premium: ${premiumUsers.length} users

🌐 <b>SERVER STATUS:</b>
├─ 🚀 SRV1: ${settings.domain && settings.domain !== '-' ? '✅' : '❌'}
├─ 🚀 SRV2: ${settings.domain2 && settings.domain2 !== '-' ? '✅' : '❌'}
└─ 🚀 SRV3: ${settings.domain3 && settings.domain3 !== '-' ? '✅' : '❌'}

━━━━━━━━━━━━━━━━━━━
⏰ Start Time: ${new Date(startTime).toLocaleString('id-ID')}
📝 Bot Status: ${botStatus === 'running' ? '🟢 RUNNING' : '🔴 STOPPED'}
━━━━━━━━━━━━━━━━━━━

<i>Gunakan /restart untuk restart bot</i>
    `;

    bot.sendMessage(chatId, statusMessage, { 
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "🔄 Restart Bot", callback_data: "restart_bot" },
                    { text: "📊 Debug", callback_data: "debug_settings" }
                ]
            ]
        }
    });
});

// START BOT Command
bot.onText(/\/startbot$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    // Jika bot sudah running
    if (botStatus === 'running') {
        return bot.sendMessage(chatId, 
            '✅ <b>Bot sudah dalam status RUNNING</b>\n\n' +
            '🤖 Bot sedang berjalan normal.\n' +
            '🕒 <b>Uptime:</b> ' + getRunDuration(startTime),
            { parse_mode: 'HTML' }
        );
    }

    try {
        // Start bot
        botStatus = 'running';
        botStoppedBy = null;
        botStoppedTime = null;

        const startMessage = `
╔══════════════════════╗
║   🚀 STARTING BOT...   ║
╚══════════════════════╝

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}

<i>Bot sedang memulai...</i>
        `;

        const sentMsg = await bot.sendMessage(chatId, startMessage, { 
            parse_mode: "HTML" 
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🚀 <b>BOT STARTED</b>

👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
            `;
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Kirim ke semua admin
        const adminMsg = `
🚀 <b>BOT STARTED</b>

👤 <b>Started by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
        `;

        adminUsers.forEach(async (adminId) => {
            if (adminId !== userId && settings.owner && adminId !== settings.owner.toString()) {
                try {
                    await bot.sendMessage(adminId, adminMsg, { parse_mode: "HTML" });
                } catch (error) {
                    console.error(`Failed to send start notification to admin ${adminId}:`, error);
                }
            }
        });

        // Update message setelah start
        setTimeout(async () => {
            try {
                await bot.editMessageText(
                    '╔══════════════════════╗\n' +
                    '║   ✅ BOT STARTED   ║\n' +
                    '╚══════════════════════╝\n\n' +
                    '🤖 Bot sekarang aktif dan siap melayani.\n' +
                    '📊 <b>Status:</b> 🟢 RUNNING',
                    {
                        chat_id: chatId,
                        message_id: sentMsg.message_id,
                        parse_mode: "HTML"
                    }
                );
            } catch (error) {
                console.error('Error editing start message:', error);
            }
        }, 2000);

    } catch (error) {
        console.error('Start command error:', error);
        bot.sendMessage(chatId, '❌ Gagal memulai bot!');
    }
});

// RESTART Command
bot.onText(/\/restart$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    const restartMessage = `
╔══════════════════════╗
║   🔄 RESTARTING BOT...   ║
╚══════════════════════╝

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Requested by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}

<i>Bot akan restart dalam 3 detik...</i>
    `;

    bot.sendMessage(chatId, restartMessage, { 
        parse_mode: "HTML" 
    }).then(() => {
        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🔁 <b>BOT RESTART REQUEST</b>

👤 <b>Requested by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
            `;
            bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Delay sebelum restart
        setTimeout(() => {
            console.log(`🔄 Bot restart requested by ${userId} at ${new Date().toLocaleString('id-ID')}`);
            process.exit(0); // Exit dengan code 0 untuk restart
        }, 3000);
    });
});

// STOP BOT Command
bot.onText(/\/stopbot$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk owner dan admin!');
    }

    // Jika bot sudah stopped
    if (botStatus === 'stopped') {
        return bot.sendMessage(chatId, 
            '╔══════════════════════╗\n' +
            '║   ❌ BOT SUDAH STOP   ║\n' +
            '╚══════════════════════╝\n\n' +
            `🛑 <b>Stopped by:</b> <code>${botStoppedBy || 'Unknown'}</code>\n` +
            `⏰ <b>Since:</b> ${botStoppedTime ? new Date(botStoppedTime).toLocaleString('id-ID') : 'Unknown'}\n\n` +
            'Gunakan <code>/startbot</code> untuk memulai bot kembali.',
            { parse_mode: 'HTML' }
        );
    }

    try {
        const stopMessage = `
╔══════════════════════╗
║   🛑 STOPPING BOT...   ║
╚══════════════════════╝

🤖 <b>Bot Name:</b> ${nama}
👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
🕒 <b>Uptime:</b> ${getRunDuration(startTime)}

⚠️ <b>Bot akan berhenti merespon command!</b>

<i>Gunakan /startbot untuk memulai kembali</i>
        `;

        const sentMsg = await bot.sendMessage(chatId, stopMessage, { 
            parse_mode: "HTML" 
        });

        // Kirim notifikasi ke owner
        if (settings.owner && userId !== settings.owner.toString()) {
            const ownerMsg = `
🛑 <b>BOT STOPPED</b>

👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
🆔 <b>User ID:</b> <code>${userId}</code>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
            `;
            await bot.sendMessage(settings.owner, ownerMsg, { parse_mode: "HTML" });
        }

        // Kirim ke semua admin
        const adminMsg = `
🛑 <b>BOT STOPPED</b>

👤 <b>Stopped by:</b> <a href="tg://user?id=${userId}">${msg.from.first_name || 'Unknown'}</a>
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
        `;

        adminUsers.forEach(async (adminId) => {
            if (adminId !== userId && settings.owner && adminId !== settings.owner.toString()) {
                try {
                    await bot.sendMessage(adminId, adminMsg, { parse_mode: "HTML" });
                } catch (error) {
                    console.error(`Failed to send stop notification to admin ${adminId}:`, error);
                }
            }
        });

        // Update status bot
        botStatus = 'stopped';
        botStoppedBy = userId;
        botStoppedTime = Date.now();

        // Update message setelah stop
        setTimeout(async () => {
            try {
                await bot.editMessageText(
                    '╔══════════════════════╗\n' +
                    '║   🛑 BOT STOPPED   ║\n' +
                    '╚══════════════════════╝\n\n' +
                    '🤖 Bot berhenti merespon command.\n' +
                    `👤 <b>Stopped by:</b> <code>${userId}</code>\n` +
                    `⏰ <b>Stopped at:</b> ${new Date().toLocaleString('id-ID')}\n` +
                    `🕒 <b>Last Uptime:</b> ${getRunDuration(startTime)}\n\n` +
                    '📝 <b>Status:</b> 🔴 STOPPED\n\n' +
                    'Gunakan <code>/startbot</code> untuk memulai bot kembali.',
                    {
                        chat_id: chatId,
                        message_id: sentMsg.message_id,
                        parse_mode: "HTML"
                    }
                );
            } catch (error) {
                console.error('Error editing stop message:', error);
            }
        }, 2000);

    } catch (error) {
        console.error('Stop command error:', error);
        bot.sendMessage(chatId, '❌ Gagal menghentikan bot!');
    }
});

// ==================== MESSAGE HANDLER FOR UPDATE SETTINGS ====================

bot.on("message", async (msg) => {
    const userId = msg.from.id.toString();
    const chatId = msg.chat.id;
    const text = msg.text ? msg.text.trim() : '';

    // Skip jika message dari bot atau command
    if (msg.from.is_bot || text.startsWith('/')) {
        return;
    }

    // Check jika user sedang dalam proses update settings
    if (tempUpdates[userId] && tempUpdates[userId].step) {
        const userData = tempUpdates[userId];

        // Handle cancel
        if (text === '/cancel') {
            delete tempUpdates[userId];
            return bot.sendMessage(chatId, "❌ Update dibatalkan.");
        }

        try {
            // Baca settings file
            let settingsContent;
            try {
                settingsContent = fs.readFileSync('./settings.js', 'utf8');
            } catch (error) {
                console.error('Error reading settings:', error);
                return bot.sendMessage(chatId, "❌ Error membaca file settings!");
            }

            let newContent = settingsContent;
            let successMessage = '';

            if (userData.type === 'plta' || userData.type === 'pltc') {
                // Validasi API Key
                const isValidPlta = text.startsWith('ptla_') && text.length >= 30;
                const isValidPltc = text.startsWith('ptlc_') && text.length >= 30;
                const isValidGeneric = text.startsWith('eyJ') && text.length >= 50;
                
                if (!isValidPlta && !isValidPltc && !isValidGeneric) {
                    return bot.sendMessage(chatId, 
                        "❌ Format API Key tidak valid!\n\n" +
                        "📝 Format yang diterima:\n" +
                        "• PLTA: <code>ptla_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n" +
                        "• PLTC: <code>ptlc_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n" +
                        "• JWT: <code>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</code>\n\n" +
                        "Silakan coba lagi atau ketik /cancel untuk membatalkan:",
                        { parse_mode: 'HTML' }
                    );
                }

                // Tentukan nama setting
                let settingName;
                if (userData.type === 'plta') {
                    settingName = userData.server === 'srv1' ? 'plta' : 
                                 userData.server === 'srv2' ? 'plta2' : 'plta3';
                } else {
                    settingName = userData.server === 'srv1' ? 'pltc' : 
                                 userData.server === 'srv2' ? 'pltc2' : 'pltc3';
                }
                
                // Update settings
                const regex = new RegExp(`(${settingName}:\\s*)['"][^'"]*['"]`, 'g');
                newContent = settingsContent.replace(regex, `$1'${text}'`);
                
                successMessage = `✅ <b>${userData.type.toUpperCase()} untuk ${userData.server.toUpperCase()} berhasil diupdate!</b>\n\n🔑 Key: <code>${text.substring(0, 15)}...</code>`;

            } else if (userData.type === 'domain') {
                // Validasi Domain
                const domainRegex = /^https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
                if (!domainRegex.test(text)) {
                    return bot.sendMessage(chatId, 
                        "❌ Format domain salah!\n\n" +
                        "📝 Format yang benar:\n" +
                        "• <code>https://panel.domain.com</code>\n" +
                        "• <code>http://localhost:8080</code>\n\n" +
                        "Silakan coba lagi atau ketik /cancel untuk membatalkan:",
                        { parse_mode: 'HTML' }
                    );
                }

                // Tentukan nama setting
                const settingName = userData.server === 'srv1' ? 'domain' : 
                                   userData.server === 'srv2' ? 'domain2' : 'domain3';
                
                // Update settings
                const regex = new RegExp(`(${settingName}:\\s*)['"][^'"]*['"]`, 'g');
                newContent = settingsContent.replace(regex, `$1'${text}'`);
                
                successMessage = `✅ <b>Domain untuk ${userData.server.toUpperCase()} berhasil diupdate!</b>\n\n🌐 Domain: <code>${text}</code>`;
            }

            // Tulis perubahan ke file
            fs.writeFileSync('./settings.js', newContent);
            
            // Kirim pesan sukses
            bot.sendMessage(chatId, successMessage + "\n\n🔄 Restart bot untuk menerapkan perubahan.", {
                parse_mode: 'HTML'
            });

            // Hapus data temporary setelah selesai
            delete tempUpdates[userId];

        } catch (error) {
            console.error('Update settings error:', error);
            bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengupdate settings!");
            delete tempUpdates[userId];
        }
    }
});

// ==================== ERROR HANDLING ====================

bot.on("polling_error", (error) => {
    console.error('Polling error:', error);
});

bot.on("error", (error) => {
    console.error('Bot error:', error);
});

// ==================== STARTUP MESSAGE ====================

console.log(`
╔══════════════════════════════════╗
║   🤖 BOT PANEL STARTED           ║
╠══════════════════════════════════╣
║ 👑 Owner: ${owner.padEnd(25)} ║
║ 📱 Name: ${nama.padEnd(26)} ║
║ 🚀 Version: ${version.padEnd(23)} ║
║ ⏰ Time: ${new Date().toLocaleString('id-ID').padEnd(20)} ║
╚══════════════════════════════════╝
`);

// Send startup notification to owner
try {
    const startupMsg = `
╔══════════════════════╗
║   🚀 BOT STARTED   ║
╚══════════════════════╝

🤖 <b>Bot Name:</b> ${nama}
👑 <b>Owner:</b> ${settings.owner ? settings.owner : 'NOT SET!'}
📈 <b>Version:</b> ${version}
⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}
📊 <b>Users:</b> ${premiumUsers.length} premium, ${adminUsers.length} admin
🔄 <b>Status:</b> ${botStatus}

${!settings.owner ? '❌ <b>WARNING: Owner not set in settings!</b>' : ''}

<i>Bot is now running and ready to serve!</i>
    `;
    
    // Hanya kirim jika owner ada
    if (settings.owner) {
        bot.sendMessage(settings.owner, startupMsg, { parse_mode: "HTML" })
            .catch(error => console.error('Failed to send startup message:', error));
    } else {
        console.error('❌ Cannot send startup message: owner not set in settings!');
    }
} catch (error) {
    console.error('Startup message error:', error);
}