// CONTOH SETTING YANG SUDAH DIISI:
const settings = {
  token: '8230402583:AAG_CyAynSxIklIDOOAcL_0Tzs_DjZxeGT8',
  owner: '7017228790',
  urladmin: 't.me/kriszzyy',
  
  // IMAGE
  thumbnail: './image/thumbnail.png',
  pterodactyl: './image/pterodactyl.png',
  
  // SERVER 1
  domain: 'https://kiwipanel.publicserverr.my.id',
  plta: 'ptla_lYzzKg853V3Y9s7yjEtoxuKNUTdbt6TAa7CRKXMV8rl',
  pltc: 'ptlc_965JV52FRQTlxDi8L0XNSokmtkGqLbBIzurZssaxgsv',
  
  // SERVER 2
  domain2: '-',
  plta2: '-', 
  pltc2: '-',
  
  // SERVER 3
  domain3: '-',
  plta3: '-',
  pltc3: '-',
  
  loc: '1',
  eggs: '15'
};

module.exports = settings;